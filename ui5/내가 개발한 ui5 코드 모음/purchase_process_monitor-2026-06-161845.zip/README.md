## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Tue Jun 16 2026 09:04:35 GMT+0900 (한국 표준시)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.24.0|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>Basic V2|
|**Service Type**<br>SAP System (ABAP On-Premise)|
|**Service URL**<br>http://61.97.134.36:8000/sap/opu/odata/sap/ZGWD3MM0002_SRV|
|**Module Name**<br>purchase_process_monitor|
|**Application Title**<br>[MM] 구매 프로세스 모니터링|
|**Namespace**<br>code.d3|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.120.23|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>True, see https://www.npmjs.com/package/@sap-ux/eslint-plugin-fiori-tools#rules for the eslint rules.|

## purchase_process_monitor

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated application, run the following from the generated application root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


