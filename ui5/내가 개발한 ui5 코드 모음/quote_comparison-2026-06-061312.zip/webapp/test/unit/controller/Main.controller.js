/*global QUnit*/

sap.ui.define([
	"code/d3/quotecomparison/controller/Main.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Main Controller");

	function createControllerWithFakeView(oOptions) {
		var oAppController = new Controller();
		var mModels = {};

		oOptions = oOptions || {};

		var oFakeView = {
			setModel: function (oModel, sName) {
				mModels[sName] = oModel;
			},
			getModel: function (sName) {
				return mModels[sName];
			},
			byId: function (sId) {
				return oOptions.controls && oOptions.controls[sId];
			}
		};

		oAppController.getView = function () {
			return oFakeView;
		};

		oAppController.byId = function (sId) {
			return oFakeView.byId(sId);
		};

		oAppController.getOwnerComponent = function () {
			return {
				getModel: function (sName) {
					if (sName && oOptions.namedModels) {
						return oOptions.namedModels[sName] || null;
					}

					return oOptions.odataModel || null;
				}
			};
		};

		return {
			controller: oAppController,
			models: mModels
		};
	}

	QUnit.test("onInit should create initial view, filter, and work models", function (assert) {
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();

		assert.strictEqual(oFixture.models.view.getProperty("/FclLayout"), "OneColumn", "FCL starts with only Begin column visible.");
		assert.strictEqual(oFixture.models.view.getProperty("/AdvancedFilterVisible"), false, "Advanced filter starts hidden.");
		assert.deepEqual(oFixture.models.filter.getProperty("/AwardStatus"), [], "Award status filter starts empty for multi-select binding.");
		assert.strictEqual(oFixture.models.work.getProperty("/RfqHeaderCount"), 0, "RFQ header count starts at zero.");
		assert.deepEqual(oFixture.models.work.getProperty("/RfqHeaders"), [], "RFQ header list starts empty.");
	});

	QUnit.test("onToggleAdvancedFilter should switch advanced filter visibility", function (assert) {
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.controller.onToggleAdvancedFilter();
		assert.strictEqual(oFixture.models.view.getProperty("/AdvancedFilterVisible"), true, "Advanced filter is shown after first toggle.");

		oFixture.controller.onToggleAdvancedFilter();
		assert.strictEqual(oFixture.models.view.getProperty("/AdvancedFilterVisible"), false, "Advanced filter is hidden after second toggle.");
	});

	QUnit.test("onKpiAwardStatusPress should filter only the RFQ header table without recalculating KPI counts", function (assert) {
		var bSearchCalled = false;
		var aAppliedFilters = null;
		var sToastMessage = "";
		var oFixture = createControllerWithFakeView({
			controls: {
				idRfqHeaderTable: {
					getBinding: function (sAggregation) {
						assert.strictEqual(sAggregation, "items", "RFQ Header table item binding is used.");
						return {
							filter: function (aFilters, sFilterType) {
								aAppliedFilters = aFilters;
								assert.strictEqual(sFilterType, "Application", "KPI filter is applied as an application-level table filter.");
							}
						};
					}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.filter.setProperty("/AwardStatus", []);
		oFixture.models.work.setProperty("/RfqHeaders", [
			{ AwardStatus: "N" },
			{ AwardStatus: "A" },
			{ AwardStatus: "PO" }
		]);
		oFixture.models.work.setProperty("/Kpi", {
			NotAwarded: 1,
			PartiallyAwarded: 0,
			Awarded: 1,
			PoCreated: 1
		});
		oFixture.controller.onSearch = function () {
			bSearchCalled = true;
			return Promise.resolve([]);
		};
		oFixture.controller._showToast = function (sMessage) {
			sToastMessage = sMessage;
		};
		oFixture.controller._getText = function (sKey) {
			return sKey === "msgKpiAwardFilterApplied" ? "KPI 채택상태 필터를 적용했습니다." : "";
		};

		oFixture.controller.onKpiAwardStatusPress({
			getSource: function () {
				return {
					data: function (sKey) {
						return sKey === "awardStatus" ? "N" : "";
					}
				};
			}
		});
		assert.deepEqual(oFixture.models.filter.getProperty("/AwardStatus"), [], "Search condition model is not changed by KPI quick filter.");
		assert.strictEqual(bSearchCalled, false, "KPI tile does not trigger a new backend search.");
		assert.strictEqual(aAppliedFilters.length, 1, "One table filter is applied.");
		assert.strictEqual(aAppliedFilters[0].sPath, "AwardStatus", "The quick filter targets AwardStatus.");
		assert.strictEqual(aAppliedFilters[0].oValue1, "N", "The selected KPI status is used as filter value.");
		assert.deepEqual(oFixture.models.work.getProperty("/Kpi"), {
			NotAwarded: 1,
			PartiallyAwarded: 0,
			Awarded: 1,
			PoCreated: 1
		}, "KPI counts stay based on the last Search result.");
		assert.strictEqual(oFixture.models.work.getProperty("/RfqHeaderCount"), 1, "Header list count reflects the visible quick-filtered rows.");
		assert.strictEqual(sToastMessage, "KPI 채택상태 필터를 적용했습니다.", "User is informed about the quick filter.");
	});

	QUnit.test("onClearAwardStatusQuickFilter should clear only the table quick filter without changing search conditions", function (assert) {
		var bSearchCalled = false;
		var aAppliedFilters = null;
		var oFixture = createControllerWithFakeView({
			controls: {
				idRfqHeaderTable: {
					getBinding: function (sAggregation) {
						assert.strictEqual(sAggregation, "items", "RFQ Header table item binding is used.");
						return {
							filter: function (aFilters) {
								aAppliedFilters = aFilters;
							}
						};
					}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.filter.setProperty("/RfqNo", "RQ00000001");
		oFixture.models.filter.setProperty("/AwardStatus", ["PO"]);
		oFixture.models.work.setProperty("/RfqHeaders", [
			{ AwardStatus: "N" },
			{ AwardStatus: "A" },
			{ AwardStatus: "PO" }
		]);
		oFixture.controller.onSearch = function () {
			bSearchCalled = true;
			return Promise.resolve([]);
		};
		oFixture.controller._showToast = function () {};

		oFixture.controller.onClearAwardStatusQuickFilter();

		assert.deepEqual(oFixture.models.filter.getProperty("/AwardStatus"), ["PO"], "Search condition award status remains unchanged.");
		assert.strictEqual(oFixture.models.filter.getProperty("/RfqNo"), "RQ00000001", "Other search conditions remain unchanged.");
		assert.strictEqual(bSearchCalled, false, "Clearing the quick filter does not trigger a backend search.");
		assert.deepEqual(aAppliedFilters, [], "Table application filters are cleared.");
		assert.strictEqual(oFixture.models.work.getProperty("/RfqHeaderCount"), 3, "Header list count returns to the last Search result row count.");
	});

	QUnit.test("onReset should clear visible search condition control values as well as the filter model", function (assert) {
		var mClearedValues = {};
		var oFixture = createControllerWithFakeView({
			controls: {
				idRfqNoInput: {
					setValue: function (sValue) {
						mClearedValues.RfqNo = sValue;
					},
					setValueState: function () {},
					setValueStateText: function () {}
				},
				idDocDateFromPicker: {
					setValue: function (sValue) {
						mClearedValues.DocDateFrom = sValue;
					},
					setDateValue: function (oDate) {
						mClearedValues.DocDateFromDate = oDate;
					},
					setValueState: function () {},
					setValueStateText: function () {}
				},
				idAwardStatusCombo: {
					setSelectedKeys: function (aKeys) {
						mClearedValues.AwardStatus = aKeys;
					}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.filter.setProperty("/RfqNo", "RQ00000001");
		oFixture.models.filter.setProperty("/DocDateFrom", new Date(2026, 4, 32));
		oFixture.models.filter.setProperty("/AwardStatus", ["N"]);

		oFixture.controller.onReset();

		assert.strictEqual(oFixture.models.filter.getProperty("/RfqNo"), "", "RFQ number model value is cleared.");
		assert.strictEqual(oFixture.models.filter.getProperty("/DocDateFrom"), null, "Document date model value is cleared.");
		assert.deepEqual(oFixture.models.filter.getProperty("/AwardStatus"), [], "Award status model value is cleared.");
		assert.strictEqual(mClearedValues.RfqNo, "", "RFQ number input value is cleared.");
		assert.strictEqual(mClearedValues.DocDateFrom, "", "DatePicker visible text is cleared.");
		assert.strictEqual(mClearedValues.DocDateFromDate, null, "DatePicker dateValue is cleared.");
		assert.deepEqual(mClearedValues.AwardStatus, [], "MultiComboBox selected keys are cleared.");
	});

	QUnit.test("_applyHeaderTableSorters should apply group sorter before sort sorter and update summaries", function (assert) {
		var aAppliedSorters = null;
		var oFixture = createControllerWithFakeView({
			controls: {
				idRfqHeaderTable: {
					getBinding: function (sAggregation) {
						assert.strictEqual(sAggregation, "items", "RFQ Header table item binding is used.");
						return {
							sort: function (aSorters) {
								aAppliedSorters = aSorters;
							}
						};
					}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.controller._getText = function (sKey) {
			var mText = {
				tableSortSummaryPrefix: "?뺣젹",
				tableGroupSummaryPrefix: "洹몃９",
				sortAscending: "?ㅻ쫫李⑥닚",
				sortDescending: "?대┝李⑥닚",
				tableStatusSummaryAll: "?곹깭: ?꾩껜",
				rfqNo: "RFQ 踰덊샇",
				awardStatus: "梨꾪깮?곹깭"
			};

			return mText[sKey] || sKey;
		};

		oFixture.controller._applyHeaderTableSorters("RfqNo", false, "AwardStatus", true);

		assert.strictEqual(aAppliedSorters.length, 2, "Group sorter and sort sorter are both applied.");
		assert.strictEqual(aAppliedSorters[0].sPath, "AwardStatus", "Group sorter is applied first.");
		assert.strictEqual(aAppliedSorters[0].bDescending, true, "Group sort direction is kept.");
		assert.strictEqual(aAppliedSorters[1].sPath, "RfqNo", "Sort sorter is applied second.");
		assert.strictEqual(oFixture.models.view.getProperty("/HeaderTableGroupKey"), "AwardStatus", "Group state is stored.");
		assert.strictEqual(oFixture.models.view.getProperty("/HeaderTableSortKey"), "RfqNo", "Sort state is stored.");
		assert.strictEqual(oFixture.models.view.getProperty("/HeaderTableSortGroupSummary"), "?뺣젹: RFQ 踰덊샇 ?ㅻ쫫李⑥닚 / 洹몃９: 梨꾪깮?곹깭 ?대┝李⑥닚", "Sort/group summary is updated.");
	});

	QUnit.test("onRfqSelectionChange should open the Mid column", function (assert) {
		var oFixture = createControllerWithFakeView({
			odataModel: {
				read: function (sPath, mParameters) {
					assert.strictEqual(sPath, "/RFQItemSet", "Selecting an RFQ starts the RFQ item query.");
					mParameters.success({
						results: []
					});
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.controller.onRfqSelectionChange({
			getParameter: function () {
				return {
					getBindingContext: function () {
						return {
							getObject: function () {
								return {
									RfqNo: "5000000123",
									AwardStatusText: "Not awarded"
								};
							}
						};
					}
				};
			}
		});

		assert.strictEqual(oFixture.models.view.getProperty("/FclLayout"), "TwoColumnsMidExpanded", "Selecting an RFQ opens the Mid column.");
		assert.strictEqual(oFixture.models.work.getProperty("/SelectedRfq/RfqNo"), "5000000123", "Selected RFQ is stored for the Mid column header.");
	});

	QUnit.test("onRfqSelectionChange should load RFQItemSet for the selected RFQ", function (assert) {
		var done = assert.async();
		var oRfq = {
			RfqNo: "5000000123",
			AwardStatusText: "Not awarded",
		};
		var aItems = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			Matnr: "100001",
			Maktx: "Bolt M10",
			ItemStatusText: "Not awarded",
			ItemStatusState: "None"
		}];
		var oFixture = createControllerWithFakeView({
			odataModel: {
				read: function (sPath, mParameters) {
					assert.strictEqual(sPath, "/RFQItemSet", "RFQItemSet is read when a header is selected.");
					assert.strictEqual(mParameters.filters.length, 1, "The selected RFQ is passed as one filter.");
					assert.strictEqual(mParameters.filters[0].sPath, "RfqNo", "RFQ item query filters by RfqNo.");
					assert.strictEqual(mParameters.filters[0].sOperator, "EQ", "RFQ item query uses exact RFQ number matching.");
					assert.strictEqual(mParameters.filters[0].oValue1, "5000000123", "Selected RFQ number is used as the filter value.");
					mParameters.success({
						results: aItems
					});
				}
			}
		});

		oFixture.controller.onInit();

		oFixture.controller.onRfqSelectionChange({
			getParameter: function () {
				return {
					getBindingContext: function () {
						return {
							getObject: function () {
								return oRfq;
							}
						};
					}
				};
			}
		}).then(function () {
			assert.deepEqual(oFixture.models.work.getProperty("/RfqItems"), aItems, "RFQ item rows are stored in the work model.");
			assert.deepEqual(oFixture.models.work.getProperty("/MqCompareRows"), [], "Previous MQ compare rows are cleared before item drilldown.");
			assert.deepEqual(oFixture.models.work.getProperty("/ChartRows"), [], "Previous chart rows are cleared before item drilldown.");
			done();
		});
	});

	QUnit.test("onRfqItemSelectionChange should keep selected item and clear stale MQ data", function (assert) {
		var oFixture = createControllerWithFakeView();
		var oRfqItem = {
			RfqNo: "5000000123",
			RfqItem: "00010",
			Matnr: "100001",
			Maktx: "Bolt M10",
			CanCancelAward: "X"
		};

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedMq", {
			MqNo: "MQ70000001",
			MqItem: "00010"
		});
		oFixture.models.work.setProperty("/MqCompareRows", [{
			MqNo: "MQ70000001",
			UiSelected: true
		}]);
		oFixture.models.work.setProperty("/ChartRows", [{
			Name1: "湲곗〈 怨듦툒?낆껜",
			NetwrKrw: 1000
		}]);

		oFixture.controller.onRfqItemSelectionChange({
			getParameter: function () {
				return {
					getBindingContext: function () {
						return {
							getObject: function () {
								return oRfqItem;
							}
						};
					}
				};
			}
		});

		assert.deepEqual(oFixture.models.work.getProperty("/SelectedRfqItem"), oRfqItem, "Selected RFQ item is stored for the comparison area.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedMq"), {}, "Previous MQ selection is cleared.");
		assert.deepEqual(oFixture.models.work.getProperty("/MqCompareRows"), [], "Previous MQ compare rows are cleared.");
		assert.deepEqual(oFixture.models.work.getProperty("/ChartRows"), [], "Previous chart rows are cleared.");
	});

	QUnit.test("onRfqItemSelectionChange should load MQCompareSet for the selected RFQ item", function (assert) {
		var done = assert.async();
		var oRfqItem = {
			RfqNo: "5000000123",
			RfqItem: "00010",
			Matnr: "100001",
			Maktx: "Bolt M10"
		};
		var aMqRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000001",
			MqItem: "00010",
			Lifnr: "V001",
			Name1: "Supplier A"
		}];
		var oFixture = createControllerWithFakeView({
			odataModel: {
				read: function (sPath, mParameters) {
					assert.strictEqual(sPath, "/MQCompareSet", "RFQ item selection reads MQCompareSet.");
					assert.strictEqual(mParameters.filters.length, 2, "MQ compare query sends RFQ number and item filters.");
					assert.strictEqual(mParameters.filters[0].sPath, "RfqNo", "First filter is RfqNo.");
					assert.strictEqual(mParameters.filters[0].sOperator, "EQ", "RfqNo uses exact matching.");
					assert.strictEqual(mParameters.filters[0].oValue1, "5000000123", "Selected RFQ number is used.");
					assert.strictEqual(mParameters.filters[1].sPath, "RfqItem", "Second filter is RfqItem.");
					assert.strictEqual(mParameters.filters[1].sOperator, "EQ", "RfqItem uses exact matching.");
					assert.strictEqual(mParameters.filters[1].oValue1, "00010", "Selected RFQ item is used.");
					mParameters.success({
						results: aMqRows
					});
				}
			}
		});

		oFixture.controller.onInit();

		oFixture.controller.onRfqItemSelectionChange({
			getParameter: function () {
				return {
					getBindingContext: function () {
						return {
							getObject: function () {
								return oRfqItem;
							}
						};
					}
				};
			}
		}).then(function () {
			assert.deepEqual(oFixture.models.work.getProperty("/SelectedRfqItem"), oRfqItem, "Selected RFQ item remains stored.");
			assert.deepEqual(oFixture.models.work.getProperty("/MqCompareRows"), [{
				RfqNo: "5000000123",
				RfqItem: "00010",
				MqNo: "MQ70000001",
				MqItem: "00010",
				Lifnr: "V001",
				Name1: "Supplier A",
				UiSelected: false
			}], "MQ compare rows are stored with no selected MQ yet.");
			assert.deepEqual(oFixture.models.work.getProperty("/SelectedMq"), {}, "No MQ is selected automatically.");
			done();
		});
	});

	QUnit.test("onRfqItemSelectionChange should prepare chart rows from valid MQ compare rows", function (assert) {
		var done = assert.async();
		var oRfqItem = {
			RfqNo: "5000000123",
			RfqItem: "00010"
		};
		var aMqRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000001",
			MqItem: "00010",
			Lifnr: "V001",
			Name1: "Supplier A",
			NetwrKrw: "240000",
			ResponseStatus: "R",
			RecommendYn: "X",
			CurrentAwardYn: ""
		}, {
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000003",
			MqItem: "00010",
			Lifnr: "V003",
			Name1: "Supplier C",
			NetwrKrw: "120000",
			ResponseStatus: "R",
			RecommendYn: "",
			CurrentAwardYn: ""
		}, {
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000002",
			MqItem: "00010",
			Lifnr: "V002",
			Name1: "Supplier B",
			NetwrKrw: "0",
			ResponseStatus: "N",
			RecommendYn: "",
			CurrentAwardYn: ""
		}];
		var oFixture = createControllerWithFakeView({
			odataModel: {
				read: function (sPath, mParameters) {
					assert.strictEqual(sPath, "/MQCompareSet", "RFQ item selection reads MQCompareSet.");
					mParameters.success({
						results: aMqRows
					});
				}
			}
		});

		oFixture.controller.onInit();

		oFixture.controller.onRfqItemSelectionChange({
			getParameter: function () {
				return {
					getBindingContext: function () {
						return {
							getObject: function () {
								return oRfqItem;
							}
						};
					}
				};
			}
		}).then(function () {
			assert.deepEqual(oFixture.models.work.getProperty("/ChartRows"), [{
				RfqNo: "5000000123",
				RfqItem: "00010",
				MqNo: "MQ70000003",
				MqItem: "00010",
				Lifnr: "V003",
				Name1: "Supplier C",
				NetwrKrw: 120000,
				RecommendYn: "",
				CurrentAwardYn: ""
			}, {
				RfqNo: "5000000123",
				RfqItem: "00010",
				MqNo: "MQ70000001",
				MqItem: "00010",
				Lifnr: "V001",
				Name1: "Supplier A",
				NetwrKrw: 240000,
				RecommendYn: "X",
				CurrentAwardYn: ""
			}], "Only valid responded MQ rows with KRW amount are prepared for the chart in ascending amount order.");
			done();
		});
	});

	QUnit.test("_sortMqCompareRowsByNetwrKrw should sort MQ compare rows by KRW amount ascending", function (assert) {
		var oFixture = createControllerWithFakeView();
		var aSortedRows;

		oFixture.controller.onInit();
		aSortedRows = oFixture.controller._sortMqCompareRowsByNetwrKrw([{
			MqNo: "MQ00000005",
			MqItem: "00020",
			NetwrKrw: "600000"
		}, {
			MqNo: "MQ70000004",
			MqItem: "00020",
			NetwrKrw: "587100"
		}, {
			MqNo: "MQ00000006",
			MqItem: "00020",
			NetwrKrw: ""
		}]);

		assert.deepEqual(aSortedRows.map(function (oRow) {
			return oRow.MqNo;
		}), ["MQ70000004", "MQ00000005", "MQ00000006"], "Rows with numeric KRW amounts come first in ascending order; missing amounts stay last.");
	});

	QUnit.test("onMqRadioSelect should keep only one selectable MQ selected", function (assert) {
		var aRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000001",
			MqItem: "00010",
			Lifnr: "V001",
			Name1: "Supplier A",
			CanSelect: "X",
			RecommendYn: "",
			CurrentAwardYn: "",
			UiSelected: true
		}, {
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000002",
			MqItem: "00010",
			Lifnr: "V002",
			Name1: "Supplier B",
			CanSelect: "X",
			RecommendYn: "X",
			CurrentAwardYn: "",
			UiSelected: false
		}];
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/MqCompareRows", aRows);

		oFixture.controller.onMqRadioSelect({
			getSource: function () {
				return {
					getBindingContext: function () {
						return {
							getObject: function () {
								return aRows[1];
							}
						};
					}
				};
			}
		});

		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/0/UiSelected"), false, "Previous MQ selection is cleared.");
		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/1/UiSelected"), true, "Selected MQ row remains selected.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedMq"), {
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000002",
			MqItem: "00010",
			Lifnr: "V002",
			Name1: "Supplier B",
			CanSelect: "X",
			BlockReason: undefined,
			RecommendYn: "X",
			CurrentAwardYn: ""
		}, "Selected MQ is stored for award actions.");
	});

	QUnit.test("onMqRadioSelect should ignore MQ rows that cannot be selected", function (assert) {
		var aRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000001",
			MqItem: "00010",
			CanSelect: "X",
			UiSelected: true
		}, {
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000002",
			MqItem: "00010",
			CanSelect: "",
			BlockReason: "誘몄쓳??MQ??梨꾪깮?????놁뒿?덈떎.",
			UiSelected: false
		}];
		var oFixture = createControllerWithFakeView();
		var oPreviousSelectedMq = {
			MqNo: "MQ70000001",
			MqItem: "00010"
		};

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/MqCompareRows", aRows);
		oFixture.models.work.setProperty("/SelectedMq", oPreviousSelectedMq);

		oFixture.controller.onMqRadioSelect({
			getSource: function () {
				return {
					getBindingContext: function () {
						return {
							getObject: function () {
								return aRows[1];
							}
						};
					}
				};
			}
		});

		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/0/UiSelected"), true, "Previous valid selection is kept.");
		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/1/UiSelected"), false, "Unselectable MQ row is not selected.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedMq"), oPreviousSelectedMq, "Selected MQ model is not overwritten by an unselectable row.");
	});

	QUnit.test("onMqRadioSelect should ignore all MQ rows when the selected RFQ item already has a PO", function (assert) {
		var aRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000001",
			MqItem: "00010",
			CanSelect: "X",
			UiSelected: false
		}];
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedRfqItem", {
			RfqNo: "5000000123",
			RfqItem: "00010",
			ItemStatus: "PO",
			PoCreatedYn: "X",
			PoNo: "4500000001"
		});
		oFixture.models.work.setProperty("/MqCompareRows", aRows);

		oFixture.controller.onMqRadioSelect({
			getSource: function () {
				return {
					getBindingContext: function () {
						return {
							getObject: function () {
								return aRows[0];
							}
						};
					}
				};
			}
		});

		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/0/UiSelected"), false, "MQ row stays unselected even if CanSelect is X.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedMq"), {}, "Selected MQ is not set for a PO-created item.");
	});

	QUnit.test("onOpenMqDetailFromRow should read detail for the clicked MQ row regardless of selectability", function (assert) {
		var done = assert.async();
		var oClickedRow = {
			MqNo: "MQ70000003",
			MqItem: "00020",
			CanSelect: "",
			CurrentAwardYn: "X"
		};
		var oDetail = {
			MqNo: "MQ70000003",
			MqItem: "00020",
			Name1: "Awarded Supplier",
			CanSelect: "",
			CurrentAwardYn: "X"
		};
		var bDialogOpened = false;
		var oFixture = createControllerWithFakeView({
			odataModel: {
				read: function (sPath, mParameters) {
					assert.strictEqual(sPath, "/MQDetailSet(MqNo='MQ70000003',MqItem='00020')", "The clicked MQ row is used as the detail key.");
					mParameters.success(oDetail);
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.controller._openMqDetailDialog = function () {
			bDialogOpened = true;
			return Promise.resolve();
		};

		oFixture.controller.onOpenMqDetailFromRow({
			getSource: function () {
				return {
					getBindingContext: function () {
						return {
							getObject: function () {
								return oClickedRow;
							}
						};
					}
				};
			}
		}).then(function () {
			assert.deepEqual(oFixture.models.detail.getProperty("/MqDetail"), oDetail, "MQ detail data is stored in the detail model.");
			assert.ok(bDialogOpened, "MQ detail dialog is opened after the detail read.");
			done();
		});
	});

	QUnit.test("onOpenMqDetail should read detail for the currently selected MQ", function (assert) {
		var done = assert.async();
		var oSelectedMq = {
			MqNo: "MQ70000004",
			MqItem: "00010"
		};
		var oDetail = {
			MqNo: "MQ70000004",
			MqItem: "00010",
			Name1: "Selected Supplier",
			CanSelect: "X"
		};
		var oFixture = createControllerWithFakeView({
			odataModel: {
				read: function (sPath, mParameters) {
					assert.strictEqual(sPath, "/MQDetailSet(MqNo='MQ70000004',MqItem='00010')", "Selected MQ is used as the detail key.");
					mParameters.success(oDetail);
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedMq", oSelectedMq);
		oFixture.controller._openMqDetailDialog = function () {
			return Promise.resolve();
		};

		oFixture.controller.onOpenMqDetail().then(function () {
			assert.deepEqual(oFixture.models.detail.getProperty("/MqDetail"), oDetail, "Selected MQ detail data is stored in the detail model.");
			done();
		});
	});

	QUnit.test("onSelectMqFromDialog should select a selectable detail MQ from the compare rows", function (assert) {
		var bDialogClosed = false;
		var aRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000001",
			MqItem: "00010",
			Lifnr: "V001",
			Name1: "Supplier A",
			CanSelect: "X",
			RecommendYn: "",
			CurrentAwardYn: "",
			UiSelected: false
		}, {
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000002",
			MqItem: "00010",
			Lifnr: "V002",
			Name1: "Supplier B",
			CanSelect: "X",
			RecommendYn: "X",
			CurrentAwardYn: "",
			UiSelected: false
		}];
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/MqCompareRows", aRows);
		oFixture.models.detail.setProperty("/MqDetail", {
			MqNo: "MQ70000002",
			MqItem: "00010",
			CanSelect: "X"
		});
		oFixture.controller.onCloseMqDetailDialog = function () {
			bDialogClosed = true;
		};

		oFixture.controller.onSelectMqFromDialog();

		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/0/UiSelected"), false, "Other MQ rows remain unselected.");
		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/1/UiSelected"), true, "Dialog MQ row is selected in the compare table.");
		assert.strictEqual(oFixture.models.work.getProperty("/SelectedMq/MqNo"), "MQ70000002", "Dialog MQ is stored as the award target.");
		assert.strictEqual(oFixture.models.work.getProperty("/SelectedMq/RecommendYn"), "X", "Selected MQ uses the compare row data, not only the detail payload.");
		assert.ok(bDialogClosed, "Dialog is closed after a successful selectable MQ selection.");
	});

	QUnit.test("onSelectMqFromDialog should ignore an unselectable detail MQ", function (assert) {
		var bDialogClosed = false;
		var oPreviousSelectedMq = {
			MqNo: "MQ70000001",
			MqItem: "00010"
		};
		var aRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000001",
			MqItem: "00010",
			CanSelect: "X",
			UiSelected: true
		}, {
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000003",
			MqItem: "00010",
			CanSelect: "",
			BlockReason: "?대? 梨꾪깮??寃ъ쟻?낅땲??",
			UiSelected: false
		}];
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/MqCompareRows", aRows);
		oFixture.models.work.setProperty("/SelectedMq", oPreviousSelectedMq);
		oFixture.models.detail.setProperty("/MqDetail", {
			MqNo: "MQ70000003",
			MqItem: "00010",
			CanSelect: "",
			BlockReason: "?대? 梨꾪깮??寃ъ쟻?낅땲??"
		});
		oFixture.controller.onCloseMqDetailDialog = function () {
			bDialogClosed = true;
		};

		oFixture.controller.onSelectMqFromDialog();

		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/0/UiSelected"), true, "Previous selection remains selected.");
		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/1/UiSelected"), false, "Unselectable detail MQ is not selected.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedMq"), oPreviousSelectedMq, "Selected MQ is not overwritten.");
		assert.notOk(bDialogClosed, "Dialog stays open so the user can read the block reason.");
	});

	QUnit.test("onApplyAutoRecommend should select the recommended MQ only when it is selectable", function (assert) {
		var aRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000001",
			MqItem: "00010",
			Lifnr: "V001",
			Name1: "Supplier A",
			RecommendYn: "X",
			CanSelect: "",
			BlockReason: "?대? 梨꾪깮??寃ъ쟻?낅땲??",
			UiSelected: false
		}, {
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000002",
			MqItem: "00010",
			Lifnr: "V002",
			Name1: "Supplier B",
			RecommendYn: "X",
			CanSelect: "X",
			CurrentAwardYn: "",
			UiSelected: false
		}];
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/MqCompareRows", aRows);

		oFixture.controller.onApplyAutoRecommend();

		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/0/UiSelected"), false, "Recommended but unselectable MQ remains unselected.");
		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/1/UiSelected"), true, "Recommended and selectable MQ is selected.");
		assert.strictEqual(oFixture.models.work.getProperty("/SelectedMq/MqNo"), "MQ70000002", "Selectable recommended MQ becomes the award target.");
	});

	QUnit.test("onApplyAutoRecommend should keep the current selection when no selectable recommendation exists", function (assert) {
		var sToastMessage = "";
		var oPreviousSelectedMq = {
			MqNo: "MQ70000001",
			MqItem: "00010"
		};
		var aRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000001",
			MqItem: "00010",
			RecommendYn: "",
			CanSelect: "X",
			UiSelected: true
		}, {
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000003",
			MqItem: "00010",
			RecommendYn: "X",
			CanSelect: "",
			BlockReason: "誘몄쓳??MQ??梨꾪깮?????놁뒿?덈떎.",
			UiSelected: false
		}];
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/MqCompareRows", aRows);
		oFixture.models.work.setProperty("/SelectedMq", oPreviousSelectedMq);
		oFixture.controller._showToast = function (sMessage) {
			sToastMessage = sMessage;
		};
		oFixture.controller._getText = function (sKey) {
			return sKey === "msgNoSelectableRecommend" ? "?좏깮 媛?ν븳 異붿쿇 MQ媛 ?놁뒿?덈떎." : "";
		};

		oFixture.controller.onApplyAutoRecommend();

		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/0/UiSelected"), true, "Previous selection remains selected.");
		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/1/UiSelected"), false, "Unselectable recommended MQ is not selected.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedMq"), oPreviousSelectedMq, "Selected MQ is not overwritten.");
		assert.strictEqual(sToastMessage, "?좏깮 媛?ν븳 異붿쿇 MQ媛 ?놁뒿?덈떎.", "User is informed when no selectable recommendation exists.");
	});

	QUnit.test("onApplyAutoRecommend should not select a recommendation when the selected RFQ item already has a PO", function (assert) {
		var aRows = [{
			RfqNo: "5000000123",
			RfqItem: "00010",
			MqNo: "MQ70000002",
			MqItem: "00010",
			RecommendYn: "X",
			CanSelect: "X",
			UiSelected: false
		}];
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedRfqItem", {
			RfqNo: "5000000123",
			RfqItem: "00010",
			ItemStatus: "PO",
			PoCreatedYn: "X"
		});
		oFixture.models.work.setProperty("/MqCompareRows", aRows);
		oFixture.controller._showToast = function () {};

		oFixture.controller.onApplyAutoRecommend();

		assert.strictEqual(oFixture.models.work.getProperty("/MqCompareRows/0/UiSelected"), false, "Recommended MQ is not selected for a PO-created item.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedMq"), {}, "Selected MQ remains empty.");
	});

	QUnit.test("onSaveAward should MERGE AWARD for the selected MQ and refresh comparison data", function (assert) {
		var done = assert.async();
		var bRefreshed = false;
		var sToastMessage = "";
		var oFixture = createControllerWithFakeView({
			odataModel: {
				update: function (sPath, oPayload, mParameters) {
					assert.strictEqual(sPath, "/QuotationItemSet(MqNo='MQ70000002',MqItem='00010')", "Selected MQ key is used for QuotationItemSet MERGE.");
					assert.deepEqual(oPayload, {
						MqNo: "MQ70000002",
						MqItem: "00010",
						ActionType: "AWARD"
					}, "AWARD payload is sent to the backend.");
					assert.strictEqual(mParameters.merge, true, "OData update is sent as MERGE.");
					mParameters.success();
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedMq", {
			MqNo: "MQ70000002",
			MqItem: "00010",
			CanSelect: "X"
		});
		oFixture.controller._confirmAction = function () {
			return Promise.resolve(true);
		};
		oFixture.controller._refreshAfterAward = function () {
			bRefreshed = true;
			return Promise.resolve();
		};
		oFixture.controller._showToast = function (sMessage) {
			sToastMessage = sMessage;
		};
		oFixture.controller._getText = function (sKey) {
			return sKey === "msgAwardSuccess" ? "寃ъ쟻??梨꾪깮?섏뿀?듬땲??" : "?좏깮??MQ瑜?梨꾪깮?섏떆寃좎뒿?덇퉴?";
		};

		oFixture.controller.onSaveAward().then(function () {
			assert.strictEqual(sToastMessage, "寃ъ쟻??梨꾪깮?섏뿀?듬땲??", "Success message is shown after successful MERGE.");
			assert.ok(bRefreshed, "RFQ item and MQ comparison data are refreshed after successful AWARD.");
			assert.strictEqual(oFixture.models.view.getProperty("/Busy"), false, "Busy state is cleared after the update flow.");
			done();
		});
	});

	QUnit.test("onSaveAward should not call MERGE when no MQ is selected", function (assert) {
		var bUpdateCalled = false;
		var sToastMessage = "";
		var oFixture = createControllerWithFakeView({
			odataModel: {
				update: function () {
					bUpdateCalled = true;
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.controller._showToast = function (sMessage) {
			sToastMessage = sMessage;
		};
		oFixture.controller._getText = function (sKey) {
			return sKey === "msgSelectMq" ? "梨꾪깮??MQ瑜??좏깮?섏꽭??" : "";
		};

		return oFixture.controller.onSaveAward().then(function () {
			assert.notOk(bUpdateCalled, "Backend update is not called without a selected MQ.");
			assert.strictEqual(sToastMessage, "梨꾪깮??MQ瑜??좏깮?섏꽭??", "User is asked to select an MQ first.");
		});
	});

	QUnit.test("onSaveAward should not call MERGE when the selected RFQ item already has a PO", function (assert) {
		var bUpdateCalled = false;
		var oFixture = createControllerWithFakeView({
			odataModel: {
				update: function () {
					bUpdateCalled = true;
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedRfqItem", {
			RfqNo: "5000000123",
			RfqItem: "00010",
			ItemStatus: "PO",
			PoCreatedYn: "X"
		});
		oFixture.models.work.setProperty("/SelectedMq", {
			MqNo: "MQ70000002",
			MqItem: "00010",
			CanSelect: "X"
		});
		oFixture.controller._showToast = function () {};

		return oFixture.controller.onSaveAward().then(function () {
			assert.notOk(bUpdateCalled, "Backend update is not called for a PO-created item.");
		});
	});

	QUnit.test("onCancelAward should MERGE CANCEL for the awarded MQ and refresh comparison data", function (assert) {
		var done = assert.async();
		var bRefreshed = false;
		var sToastMessage = "";
		var oFixture = createControllerWithFakeView({
			odataModel: {
				update: function (sPath, oPayload, mParameters) {
					assert.strictEqual(sPath, "/QuotationItemSet(MqNo='MQ70000002',MqItem='00010')", "Awarded MQ key is used for QuotationItemSet MERGE.");
					assert.deepEqual(oPayload, {
						MqNo: "MQ70000002",
						MqItem: "00010",
						ActionType: "CANCEL"
					}, "CANCEL payload is sent to the backend.");
					assert.strictEqual(mParameters.merge, true, "OData update is sent as MERGE.");
					mParameters.success();
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedRfqItem", {
			RfqNo: "5000000123",
			RfqItem: "00010",
			AwardMqNo: "MQ70000002",
			AwardMqItem: "00010",
			CanCancelAward: "X"
		});
		oFixture.controller._confirmAction = function () {
			return Promise.resolve(true);
		};
		oFixture.controller._refreshAfterAward = function () {
			bRefreshed = true;
			return Promise.resolve();
		};
		oFixture.controller._showToast = function (sMessage) {
			sToastMessage = sMessage;
		};
		oFixture.controller._getText = function (sKey) {
			if (sKey === "msgCancelSuccess") {
				return "寃ъ쟻 梨꾪깮??痍⑥냼?섏뿀?듬땲??";
			}

			if (sKey === "msgConfirmCancel") {
				return "?꾩옱 梨꾪깮??MQ瑜?梨꾪깮痍⑥냼?섏떆寃좎뒿?덇퉴?";
			}

			return "";
		};

		oFixture.controller.onCancelAward().then(function () {
			assert.strictEqual(sToastMessage, "寃ъ쟻 梨꾪깮??痍⑥냼?섏뿀?듬땲??", "Success message is shown after successful CANCEL.");
			assert.ok(bRefreshed, "RFQ item and MQ comparison data are refreshed after successful CANCEL.");
			assert.strictEqual(oFixture.models.view.getProperty("/Busy"), false, "Busy state is cleared after the update flow.");
			done();
		});
	});

	QUnit.test("onCancelAward should not call MERGE when the selected RFQ item cannot be cancelled", function (assert) {
		var bUpdateCalled = false;
		var sToastMessage = "";
		var oFixture = createControllerWithFakeView({
			odataModel: {
				update: function () {
					bUpdateCalled = true;
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedRfqItem", {
			RfqNo: "5000000123",
			RfqItem: "00010",
			CanCancelAward: ""
		});
		oFixture.controller._showToast = function (sMessage) {
			sToastMessage = sMessage;
		};
		oFixture.controller._getText = function (sKey) {
			return sKey === "msgNoAwardToCancel" ? "梨꾪깮痍⑥냼??MQ媛 ?놁뒿?덈떎." : "";
		};

		return oFixture.controller.onCancelAward().then(function () {
			assert.notOk(bUpdateCalled, "Backend update is not called without a cancellable awarded MQ.");
			assert.strictEqual(sToastMessage, "梨꾪깮痍⑥냼??MQ媛 ?놁뒿?덈떎.", "User is informed that there is no award to cancel.");
		});
	});

	QUnit.test("onCancelAward should not call MERGE when the selected RFQ item already has a PO", function (assert) {
		var bUpdateCalled = false;
		var oFixture = createControllerWithFakeView({
			odataModel: {
				update: function () {
					bUpdateCalled = true;
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedRfqItem", {
			RfqNo: "5000000123",
			RfqItem: "00010",
			ItemStatus: "PO",
			PoCreatedYn: "X",
			AwardMqNo: "MQ70000002",
			AwardMqItem: "00010",
			CanCancelAward: "X"
		});
		oFixture.controller._showToast = function () {};

		return oFixture.controller.onCancelAward().then(function () {
			assert.notOk(bUpdateCalled, "Backend update is not called for a PO-created item.");
		});
	});

	QUnit.test("_isRfqItemAwarded should not treat helper MQ keys as awarded state", function (assert) {
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();

		assert.notOk(oFixture.controller._isRfqItemAwarded({
			RfqNo: "5000000123",
			RfqItem: "00020",
			ItemStatus: "N",
			ItemStatusText: "Not awarded",
			AwardMqNo: "MQ70000002",
			AwardMqItem: "00020",
			CanCancelAward: ""
		}), "A not-awarded item is not skipped only because AwardMqNo/AwardMqItem values exist.");

		assert.ok(oFixture.controller._isRfqItemAwarded({
			RfqNo: "5000000123",
			RfqItem: "00010",
			ItemStatus: "A",
			CanCancelAward: "X"
		}), "An awarded item is detected by ItemStatus or CanCancelAward.");
	});

	QUnit.test("_refreshAfterAward should preserve the current Mid column layout while reloading data", function (assert) {
		var done = assert.async();
		var aReadPaths = [];
		var oSelectedRfq = {
			RfqNo: "5000000123",
			AwardStatusText: "Not awarded"
		};
		var oUpdatedItem = {
			RfqNo: "5000000123",
			RfqItem: "00010",
			ItemStatusText: "Awarded",
			CanCancelAward: "X"
		};
		var oFixture = createControllerWithFakeView({
			odataModel: {
				read: function (sPath, mParameters) {
					aReadPaths.push(sPath);

					if (sPath === "/RFQHeaderSet") {
						mParameters.success({
							results: [
								oSelectedRfq,
								{ RfqNo: "5000000456", AwardStatusText: "Not awarded" }
							]
						});
						return;
					}

					if (sPath === "/RFQItemSet") {
						mParameters.success({
							results: [oUpdatedItem]
						});
						return;
					}

					assert.strictEqual(sPath, "/MQCompareSet", "MQ comparison is reloaded for the remembered RFQ item.");
					mParameters.success({
						results: [{
							RfqNo: "5000000123",
							RfqItem: "00010",
							MqNo: "MQ70000002",
							MqItem: "00010",
							CurrentAwardYn: "X",
							CanSelect: ""
						}]
					});
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.view.setProperty("/FclLayout", "TwoColumnsMidExpanded");
		oFixture.models.work.setProperty("/SelectedRfq", oSelectedRfq);
		oFixture.models.work.setProperty("/SelectedRfqItem", {
			RfqNo: "5000000123",
			RfqItem: "00010",
			ItemStatusText: "Not awarded"
		});

		oFixture.controller._refreshAfterAward().then(function () {
			assert.deepEqual(aReadPaths, ["/RFQHeaderSet", "/RFQItemSet", "/MQCompareSet"], "Header, item, and MQ data are refreshed in order.");
			assert.strictEqual(oFixture.models.view.getProperty("/FclLayout"), "TwoColumnsMidExpanded", "Award refresh keeps the user in the Mid column layout.");
			assert.deepEqual(oFixture.models.work.getProperty("/SelectedRfq"), oSelectedRfq, "Selected RFQ context is restored after header refresh.");
			assert.strictEqual(oFixture.models.work.getProperty("/SelectedRfqItem/ItemStatusText"), "Awarded", "Selected RFQ item context is replaced with the refreshed item row.");
			done();
		});
	});

	QUnit.test("Mid column navigation actions should switch the FCL layout", function (assert) {
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.models.view.setProperty("/FclLayout", "TwoColumnsMidExpanded");

		oFixture.controller.onEnterMidFullScreen();
		assert.strictEqual(oFixture.models.view.getProperty("/FclLayout"), "MidColumnFullScreen", "Full screen action expands the Mid column.");

		oFixture.controller.onExitMidFullScreen();
		assert.strictEqual(oFixture.models.view.getProperty("/FclLayout"), "TwoColumnsMidExpanded", "Exit full screen returns to the two-column comparison layout.");
	});

	QUnit.test("Mid column close action should clear the selected RFQ context", function (assert) {
		var oFixture = createControllerWithFakeView();

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/SelectedRfq", {
			RfqNo: "5000000123"
		});
		oFixture.models.work.setProperty("/RfqItems", [{ RfqItem: "00010" }]);
		oFixture.models.view.setProperty("/FclLayout", "TwoColumnsMidExpanded");

		oFixture.controller.onCloseMidColumn();

		assert.strictEqual(oFixture.models.view.getProperty("/FclLayout"), "OneColumn", "Close action returns to the Begin column only.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedRfq"), {}, "Selected RFQ header is cleared.");
		assert.deepEqual(oFixture.models.work.getProperty("/RfqItems"), [], "RFQ item rows are cleared with the closed Mid column.");
	});

	QUnit.test("_clearRfqItemDependentArea should clear remembered RFQ item table selection", function (assert) {
		var bRemoveAll;
		var oFixture = createControllerWithFakeView({
			controls: {
				idRfqItemTable: {
					removeSelections: function (bAll) {
						bRemoveAll = bAll;
					}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.work.setProperty("/RfqItems", [{ RfqItem: "00010" }]);
		oFixture.models.work.setProperty("/SelectedRfqItem", { RfqItem: "00010" });
		oFixture.models.work.setProperty("/MqCompareRows", [{ MqNo: "MQ70000001" }]);

		oFixture.controller._clearRfqItemDependentArea();

		assert.strictEqual(bRemoveAll, true, "All remembered sap.m.Table selections are removed.");
		assert.deepEqual(oFixture.models.work.getProperty("/RfqItems"), [], "RFQ item rows are cleared.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedRfqItem"), {}, "Selected RFQ item model state is cleared.");
		assert.deepEqual(oFixture.models.work.getProperty("/MqCompareRows"), [], "MQ compare rows are cleared.");
	});

	QUnit.test("_clearSelectionAndComparisonArea should clear remembered header and item table selections", function (assert) {
		var mRemoveAll = {};
		var oFixture = createControllerWithFakeView({
			controls: {
				idRfqHeaderTable: {
					removeSelections: function (bAll) {
						mRemoveAll.header = bAll;
					}
				},
				idRfqItemTable: {
					removeSelections: function (bAll) {
						mRemoveAll.item = bAll;
					}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.view.setProperty("/FclLayout", "TwoColumnsMidExpanded");
		oFixture.models.work.setProperty("/SelectedRfq", { RfqNo: "5000000123" });
		oFixture.models.work.setProperty("/SelectedRfqItem", { RfqItem: "00010" });

		oFixture.controller._clearSelectionAndComparisonArea();

		assert.deepEqual(mRemoveAll, { header: true, item: true }, "All remembered sap.m.Table selections are removed.");
		assert.strictEqual(oFixture.models.view.getProperty("/FclLayout"), "OneColumn", "FCL layout is reset.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedRfq"), {}, "Selected RFQ header is cleared.");
		assert.deepEqual(oFixture.models.work.getProperty("/SelectedRfqItem"), {}, "Selected RFQ item is cleared.");
	});

	QUnit.test("_buildHeaderFilters should convert filter model to OData filters", function (assert) {
		var oFixture = createControllerWithFakeView();
		var aFilters;
		var oStatusFilter;

		oFixture.controller.onInit();
		oFixture.models.filter.setData({
			RfqNo: "5000000123",
			DocDateFrom: new Date(2026, 4, 1),
			DocDateTo: new Date(2026, 4, 31),
			AwardStatus: ["N", "P"],
			Lifnr: "SUP001",
			Name1: "ABC",
			Matnr: "100001",
			Maktx: "Bolt",
			Werks: "P001",
			EindtFrom: new Date(2026, 5, 1),
			EindtTo: new Date(2026, 5, 30),
			MqNo: "MQ70000001",
			Bukrs: "1000",
			Ekorg: "1010",
			Ekgrp: "001"
		});

		aFilters = oFixture.controller._buildHeaderFilters();
		oStatusFilter = aFilters[aFilters.length - 1];

		assert.strictEqual(aFilters.length, 15, "All filled search conditions become OData filters.");
		assert.strictEqual(aFilters[0].sPath, "RfqNo", "RFQ number uses RfqNo property.");
		assert.strictEqual(aFilters[0].sOperator, "EQ", "RFQ number uses EQ operator.");
		assert.strictEqual(aFilters[1].sPath, "DocDate", "Document date from uses DocDate property.");
		assert.strictEqual(aFilters[1].sOperator, "GE", "Document date from uses GE operator.");
		assert.strictEqual(aFilters[2].sOperator, "LE", "Document date to uses LE operator.");
		assert.notOk(oStatusFilter.bAnd, "Multiple award statuses are grouped with OR.");
		assert.strictEqual(oStatusFilter.aFilters.length, 2, "Two selected award statuses create two inner filters.");
	});

	QUnit.test("onSearch should stop and show validation messages when document date text is invalid", function (assert) {
		var bLoadCalled = false;
		var bPopoverOpened = false;
		var oFixture = createControllerWithFakeView({
			controls: {
				idDocDateFromPicker: {
					getValue: function () {
						return "2026-05-32";
					},
					setValueState: function (sState) {
						this.valueState = sState;
					},
					setValueStateText: function (sText) {
						this.valueStateText = sText;
					}
				},
				idDocDateToPicker: {
					getValue: function () {
						return "";
					},
					setValueState: function () {},
					setValueStateText: function () {}
				},
				idEindtFromPicker: {
					getValue: function () {
						return "";
					},
					setValueState: function () {},
					setValueStateText: function () {}
				},
				idEindtToPicker: {
					getValue: function () {
						return "";
					},
					setValueState: function () {},
					setValueStateText: function () {}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.controller._loadRfqHeaders = function () {
			bLoadCalled = true;
			return Promise.resolve([]);
		};
		oFixture.controller._openValidationMessagePopoverDelayed = function () {
			bPopoverOpened = true;
		};
		oFixture.controller._getText = function (sKey, aArgs) {
			var mText = {
				docDateFrom: "문서일자 From",
				validationDateFormatInvalid: "날짜 입력 필드는 yyyy-MM-dd 형식으로 입력해야합니다.",
				validationMessageDescription: "메시지를 선택하면 해당 조회조건으로 이동합니다.",
				validationErrorCount: "{0}"
			};
			var sText = mText[sKey] || sKey;

			return aArgs ? sText.replace("{0}", aArgs[0]) : sText;
		};

		oFixture.controller.onSearch();

		assert.strictEqual(bLoadCalled, false, "Backend search is not called for invalid date text.");
		assert.strictEqual(bPopoverOpened, true, "Validation MessagePopover is requested.");
		assert.strictEqual(oFixture.models.messages.getProperty("/count"), 1, "One validation message is stored.");
		assert.strictEqual(oFixture.models.messages.getProperty("/buttonText"), "1", "Footer button shows only the error count.");
		assert.strictEqual(oFixture.models.messages.getProperty("/items/0/controlId"), "idDocDateFromPicker", "The invalid date picker is linked.");
		assert.strictEqual(oFixture.models.messages.getProperty("/items/0/title"), "날짜 입력 필드는 yyyy-MM-dd 형식으로 입력해야합니다.", "The invalid date message follows the delayed PO monitor wording.");
	});

	QUnit.test("onSearch should stop when date range is reversed", function (assert) {
		var bLoadCalled = false;
		var oFixture = createControllerWithFakeView({
			controls: {
				idDocDateFromPicker: {
					getValue: function () {
						return "2026-06-10";
					},
					setValueState: function () {},
					setValueStateText: function () {}
				},
				idDocDateToPicker: {
					getValue: function () {
						return "2026-06-01";
					},
					setValueState: function () {},
					setValueStateText: function () {}
				},
				idEindtFromPicker: {
					getValue: function () {
						return "";
					},
					setValueState: function () {},
					setValueStateText: function () {}
				},
				idEindtToPicker: {
					getValue: function () {
						return "";
					},
					setValueState: function () {},
					setValueStateText: function () {}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.filter.setProperty("/DocDateFrom", new Date(2026, 5, 10));
		oFixture.models.filter.setProperty("/DocDateTo", new Date(2026, 5, 1));
		oFixture.controller._loadRfqHeaders = function () {
			bLoadCalled = true;
			return Promise.resolve([]);
		};
		oFixture.controller._openValidationMessagePopoverDelayed = function () {};
		oFixture.controller._getText = function (sKey, aArgs) {
			var mText = {
				docDateFrom: "문서일자 From",
				docDateTo: "문서일자 To",
				validationDocDateRangeInvalid: "문서일자 From은 문서일자 To보다 늦을 수 없습니다.",
				validationMessageDescription: "메시지를 선택하면 해당 조회조건으로 이동합니다.",
				validationErrorCount: "{0}"
			};
			var sText = mText[sKey] || sKey;

			if (aArgs) {
				aArgs.forEach(function (sArg, iIndex) {
					sText = sText.replace("{" + iIndex + "}", sArg);
				});
			}

			return sText;
		};

		oFixture.controller.onSearch();

		assert.strictEqual(bLoadCalled, false, "Backend search is not called for reversed date range.");
		assert.strictEqual(oFixture.models.messages.getProperty("/count"), 2, "Both date fields receive validation messages.");
		assert.strictEqual(oFixture.models.messages.getProperty("/items/0/controlId"), "idDocDateFromPicker", "From field is linked.");
		assert.strictEqual(oFixture.models.messages.getProperty("/items/1/controlId"), "idDocDateToPicker", "To field is linked.");
	});

	QUnit.test("onSearch should stop and show MessagePopover when a typed vendor code does not exist", function (assert) {
		var done = assert.async();
		var bLoadCalled = false;
		var bPopoverOpened = false;
		var oVendorInput = {
			setValueState: function (sState) {
				this.valueState = sState;
			},
			setValueStateText: function (sText) {
				this.valueStateText = sText;
			}
		};
		var oFixture = createControllerWithFakeView({
			controls: {
				idDocDateFromPicker: { getValue: function () { return ""; }, setValueState: function () {}, setValueStateText: function () {} },
				idDocDateToPicker: { getValue: function () { return ""; }, setValueState: function () {}, setValueStateText: function () {} },
				idEindtFromPicker: { getValue: function () { return ""; }, setValueState: function () {}, setValueStateText: function () {} },
				idEindtToPicker: { getValue: function () { return ""; }, setValueState: function () {}, setValueStateText: function () {} },
				idLifnrInput: oVendorInput
			},
			namedModels: {
				vendorHelp: {
					read: function (sPath, mParameters) {
						assert.strictEqual(sPath, "/ZCDS_D3_MM_0013", "Vendor Help EntitySet is used for existence validation.");
						assert.strictEqual(mParameters.filters[0].sPath, "Lifnr", "Vendor code is checked by Lifnr.");
						assert.strictEqual(mParameters.filters[0].oValue1, "V99999", "Typed vendor code is passed to the Help OData.");
						mParameters.success({ results: [] });
					}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.filter.setProperty("/Lifnr", "V99999");
		oFixture.controller._loadRfqHeaders = function () {
			bLoadCalled = true;
			return Promise.resolve([]);
		};
		oFixture.controller._openValidationMessagePopoverDelayed = function () {
			bPopoverOpened = true;
		};
		oFixture.controller._getText = function (sKey, aArgs) {
			var mText = {
				lifnr: "공급업체코드",
				validationCodeNotFound: "{0}에 존재하지 않는 값입니다.",
				validationMessageDescription: "메시지를 선택하면 해당 조회조건으로 이동합니다.",
				validationErrorCount: "{0}"
			};
			var sText = mText[sKey] || sKey;

			if (aArgs) {
				aArgs.forEach(function (sArg, iIndex) {
					sText = sText.replace("{" + iIndex + "}", sArg);
				});
			}

			return sText;
		};

		oFixture.controller.onSearch().then(function (vResult) {
			assert.strictEqual(vResult, false, "Search returns false when code existence validation fails.");
			assert.strictEqual(bLoadCalled, false, "RFQHeaderSet is not read.");
			assert.strictEqual(bPopoverOpened, true, "Validation MessagePopover is requested.");
			assert.strictEqual(oFixture.models.messages.getProperty("/count"), 1, "One validation message is stored.");
			assert.strictEqual(oFixture.models.messages.getProperty("/items/0/controlId"), "idLifnrInput", "Vendor input is linked.");
			assert.strictEqual(oFixture.models.messages.getProperty("/items/0/title"), "공급업체코드에 존재하지 않는 값입니다.", "Message uses the field label.");
			assert.strictEqual(oVendorInput.valueState, "Error", "Vendor input is marked as an error.");
			done();
		});
	});

	QUnit.test("onSearch should validate external material code with ALPHA input value", function (assert) {
		var done = assert.async();
		var bLoadCalled = false;
		var oFixture = createControllerWithFakeView({
			controls: {
				idDocDateFromPicker: { getValue: function () { return ""; }, setValueState: function () {}, setValueStateText: function () {} },
				idDocDateToPicker: { getValue: function () { return ""; }, setValueState: function () {}, setValueStateText: function () {} },
				idEindtFromPicker: { getValue: function () { return ""; }, setValueState: function () {}, setValueStateText: function () {} },
				idEindtToPicker: { getValue: function () { return ""; }, setValueState: function () {}, setValueStateText: function () {} },
				idMatnrInput: { setValueState: function () {}, setValueStateText: function () {} }
			},
			namedModels: {
				materialHelp: {
					read: function (sPath, mParameters) {
						assert.strictEqual(sPath, "/ZCDS_D3_MM_0014", "Material Help EntitySet is used.");
						assert.strictEqual(mParameters.filters[0].sPath, "Matnr", "Material code is checked by Matnr.");
						assert.strictEqual(mParameters.filters[0].oValue1, "0000100002", "External material code is converted to ALPHA input.");
						mParameters.success({ results: [{ Matnr: "0000100002", Maktx: "Kids Frame" }] });
					}
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.filter.setProperty("/Matnr", "100002");
		oFixture.controller._loadRfqHeaders = function () {
			bLoadCalled = true;
			return Promise.resolve([]);
		};
		oFixture.controller._openValidationMessagePopoverDelayed = function () {};

		oFixture.controller.onSearch().then(function () {
			assert.strictEqual(bLoadCalled, true, "Search continues when the material exists.");
			assert.strictEqual(oFixture.models.messages.getProperty("/count"), 0, "No validation message remains.");
			done();
		});
	});

	QUnit.test("Search Help config should include RFQ, MQ, purchasing organization, and purchasing group", function (assert) {
		var oFixture = createControllerWithFakeView();
		var oRfqConfig;
		var oMqConfig;
		var oPurchOrgConfig;
		var oPurchGroupConfig;

		oFixture.controller.onInit();
		oFixture.controller._getText = function (sKey) {
			return sKey;
		};

		oRfqConfig = oFixture.controller._getValueHelpConfig("RFQ");
		oMqConfig = oFixture.controller._getValueHelpConfig("MQ");
		oPurchOrgConfig = oFixture.controller._getValueHelpConfig("PURCH_ORG");
		oPurchGroupConfig = oFixture.controller._getValueHelpConfig("PURCH_GROUP");

		assert.strictEqual(oRfqConfig.model, "rfqHelp", "RFQ Search Help uses the RFQ named model.");
		assert.strictEqual(oRfqConfig.path, "/ZCDS_D3_MM_0021", "RFQ Search Help reads the new CDS entity set.");
		assert.strictEqual(oRfqConfig.targetFields.RfqNo.controlId, "idRfqNoInput", "RFQ number is written to the RFQ input.");
		assert.strictEqual(oMqConfig.model, "mqHelp", "MQ Search Help uses the MQ named model.");
		assert.strictEqual(oMqConfig.path, "/ZCDS_D3_MM_0022", "MQ Search Help reads the new CDS entity set.");
		assert.strictEqual(oPurchOrgConfig.model, "purchOrgHelp", "Purchasing organization uses its named model.");
		assert.strictEqual(oPurchOrgConfig.targetFields.Ekorg.path, "/Ekorg", "Purchasing organization writes to filter>/Ekorg.");
		assert.strictEqual(oPurchGroupConfig.model, "purchGroupHelp", "Purchasing group uses its named model.");
		assert.strictEqual(oPurchGroupConfig.targetFields.Ekgrp.path, "/Ekgrp", "Purchasing group writes to filter>/Ekgrp.");
	});

	QUnit.test("onSearch should load RFQHeaderSet and update Begin column models", function (assert) {
		var done = assert.async();
		var oHeader = {
			RfqNo: "5000000123",
			DocDate: new Date(2026, 4, 20),
			RfqItemCount: 4,
			MqCount: 8,
			VendorCount: 3,
			AwardStatus: "N",
			AwardStatusText: "Not awarded",
			AwardStatusState: "None"
		};
		var oFixture = createControllerWithFakeView({
			namedModels: {
				rfqHelp: {
					read: function (sPath, mParameters) {
						assert.strictEqual(sPath, "/ZCDS_D3_MM_0021", "RFQ existence validation uses the RFQ Help CDS.");
						assert.strictEqual(mParameters.filters[0].sPath, "RfqNo", "RFQ existence validation filters by RfqNo.");
						assert.strictEqual(mParameters.filters[0].oValue1, "5000000123", "Typed RFQ number is checked.");
						mParameters.success({
							results: [{ RfqNo: "5000000123" }]
						});
					}
				}
			},
			odataModel: {
				read: function (sPath, mParameters) {
					if (sPath === "/RFQHeaderSet") {
						assert.ok(Array.isArray(mParameters.filters), "OData filters are passed as an array.");
						mParameters.success({
							results: [oHeader]
						});
						return;
					}

					assert.strictEqual(sPath, "/RFQItemSet", "Single RFQ header result also starts the RFQ item query.");
					mParameters.success({
						results: []
					});
				}
			}
		});

		oFixture.controller.onInit();
		oFixture.models.filter.setProperty("/RfqNo", "5000000123");

		oFixture.controller.onSearch().then(function () {
			assert.strictEqual(oFixture.models.work.getProperty("/RfqHeaderCount"), 1, "Header count is updated.");
			assert.deepEqual(oFixture.models.work.getProperty("/RfqHeaders"), [oHeader], "Header rows are stored in the work model.");
			assert.strictEqual(oFixture.models.work.getProperty("/Kpi/NotAwarded"), 1, "KPI for not awarded headers is calculated.");
			assert.strictEqual(oFixture.models.view.getProperty("/FclLayout"), "TwoColumnsMidExpanded", "Single result opens Mid column automatically.");
			assert.strictEqual(oFixture.models.work.getProperty("/SelectedRfq/RfqNo"), "5000000123", "Single result is stored as selected RFQ.");
			done();
		});
	});
});
