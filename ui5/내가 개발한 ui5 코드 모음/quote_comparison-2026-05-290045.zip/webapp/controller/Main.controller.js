sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/Sorter",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/Fragment",
    "code/d3/quotecomparison/model/formatter"
], (Controller, JSONModel, Filter, FilterOperator, Sorter, MessageToast, MessageBox, Fragment, formatter) => {
    "use strict";

    return Controller.extend("code.d3.quotecomparison.controller.Main", {
        formatter: formatter,

        onInit() {
            this._initViewModels();
            this._applyHeaderQuickAwardStatusFilter("", true);
        },

        /**
         * 화면에서 사용하는 JSONModel을 초기화한다.
         *
         * view  : Busy, 상세조건 표시 여부, FlexibleColumnLayout 상태처럼 화면 제어용 값
         * filter: DynamicPage Header의 조회조건 값
         * work  : RFQ/MQ 조회 결과, 선택된 RFQ/MQ, KPI처럼 업무 화면에 표시되는 값
         *
         * 실제 OData 응답은 `work` 모델에 넣고, 화면 제어 상태는 `view` 모델에 둔다.
         * 이렇게 나누면 조회 데이터가 바뀌어도 레이아웃 상태와 업무 데이터가 서로 섞이지 않는다.
         */
        _initViewModels() {
            const oView = this.getView();

            oView.setModel(new JSONModel(this._createInitialViewData()), "view");
            oView.setModel(new JSONModel(this._createInitialFilterData()), "filter");
            oView.setModel(new JSONModel(this._createInitialWorkData()), "work");
            oView.setModel(new JSONModel(this._createInitialDetailData()), "detail");
        },

        /**
         * 화면 제어 모델의 초기값을 반환한다.
         *
         * FCL은 최초 진입 시 Begin Column만 보여준다.
         * RFQ Header 행을 선택하거나 RFQ Header 조회 결과가 정확히 1건일 때 Mid Column을 연다.
         */
        _createInitialViewData() {
            return {
                Busy: false,
                AdvancedFilterVisible: false,
                FclLayout: "OneColumn",
                HeaderTableStatusSummary: "",
                HeaderTableSortGroupSummary: "",
                HeaderTableQuickAwardStatus: "",
                HeaderTableSortKey: "",
                HeaderTableSortDescending: false,
                HeaderTableGroupKey: "",
                HeaderTableGroupDescending: false
            };
        },

        /**
         * 조회조건 모델의 초기값을 반환한다.
         *
         * DatePicker의 dateValue는 Date 객체 또는 null을 기대하므로 날짜 필드는 null로 둔다.
         * 채택상태는 MultiComboBox의 selectedKeys 바인딩에 맞춰 배열로 둔다.
         */
        _createInitialFilterData() {
            return {
                RfqNo: "",
                DocDateFrom: null,
                DocDateTo: null,
                AwardStatus: [],
                Lifnr: "",
                Name1: "",
                Matnr: "",
                Maktx: "",
                Werks: "",
                EindtFrom: null,
                EindtTo: null,
                MqNo: "",
                Bukrs: "",
                Ekorg: "",
                Ekgrp: ""
            };
        },

        /**
         * 업무 데이터 모델의 초기값을 반환한다.
         *
         * 현재 화면은 Header -> Item -> MQ 비교 순서로 단계적으로 데이터를 채운다.
         * 따라서 Header 조회 전에는 모든 배열과 선택 객체를 비워 두고, 조회 단계마다 해당 경로만 갱신한다.
         */
        _createInitialWorkData() {
            return {
                Kpi: {
                    NotAwarded: 0,
                    PartiallyAwarded: 0,
                    Awarded: 0,
                    PoCreated: 0
                },
                RfqHeaderCount: 0,
                RfqHeaders: [],
                RfqItems: [],
                MqCompareRows: [],
                ChartRows: [],
                SelectedRfq: {},
                SelectedRfqItem: {},
                SelectedMq: {}
            };
        },

        _createInitialDetailData() {
            return {
                MqDetail: {}
            };
        },

        /**
         * 조회 버튼 이벤트.
         *
         * 이번 단계에서는 Begin Column에 필요한 RFQHeaderSet만 조회한다.
         * Header 행을 클릭했을 때 RFQItemSet을 읽는 로직은 다음 단계에서 붙인다.
         */
        onSearch() {
            return this._loadRfqHeaders();
        },

        /**
         * 조회조건 초기화 버튼 이벤트.
         *
         * 필터 값은 최초 상태로 되돌리고, 상세조건 영역도 닫는다.
         * 이미 조회된 Header 목록은 사용자가 새로 조회하기 전까지 유지한다.
         */
        onReset() {
            const oView = this.getView();
            const oViewModel = oView.getModel("view");

            oView.setModel(new JSONModel(this._createInitialFilterData()), "filter");

            if (oViewModel) {
                oViewModel.setProperty("/AdvancedFilterVisible", false);
            }

            this._applyHeaderQuickAwardStatusFilter("", true);
        },

        /**
         * RFQ Header KPI 카드 클릭 이벤트.
         *
         * KPI 카드는 조회 결과 요약 숫자를 유지한 상태에서 RFQ Header Table만 빠르게 좁혀 보는 용도다.
         * 따라서 조회조건 모델은 변경하지 않고, 이미 조회된 Table binding에만 채택상태 필터를 적용한다.
         */
        onKpiAwardStatusPress(oEvent) {
            const oSource = oEvent && oEvent.getSource && oEvent.getSource();
            const sAwardStatus = oSource && oSource.data && oSource.data("awardStatus");

            if (!sAwardStatus) {
                this._showToast(this._getText("msgKpiAwardFilterUnknown") || "알 수 없는 KPI 필터입니다.");
                return Promise.resolve(null);
            }

            this._applyHeaderQuickAwardStatusFilter(sAwardStatus);
            this._showToast(this._getText("msgKpiAwardFilterApplied") || "KPI 채택상태 필터를 적용했습니다.");

            return Promise.resolve(sAwardStatus);
        },

        /**
         * KPI로 적용한 채택상태 빠른 필터를 해제한다.
         *
         * 검색조건 전체 초기화가 아니라 채택상태 조건만 비운 뒤 현재 다른 조회조건은 유지하고 재조회한다.
         */
        onClearAwardStatusQuickFilter() {
            this._applyHeaderQuickAwardStatusFilter("");
            this._showToast(this._getText("msgKpiAwardFilterCleared") || "KPI 채택상태 필터를 해제했습니다.");

            return Promise.resolve(null);
        },

        /**
         * RFQ Header Table 정렬/그룹 설정 Dialog를 연다.
         *
         * Dialog는 Fragment로 분리하고 최초 1회만 생성해 재사용한다.
         */
        onOpenRfqHeaderTableSettings() {
            const oView = this.getView();

            if (!this._pRfqHeaderTableSettingsDialog) {
                this._pRfqHeaderTableSettingsDialog = Fragment.load({
                    id: oView.getId(),
                    name: "code.d3.quotecomparison.fragment.RfqHeaderTableSettings",
                    controller: this
                }).then((oDialog) => {
                    if (oView.addDependent) {
                        oView.addDependent(oDialog);
                    }

                    return oDialog;
                });
            }

            return this._pRfqHeaderTableSettingsDialog.then((oDialog) => {
                oDialog.open();
                return oDialog;
            });
        },

        /**
         * ViewSettingsDialog의 선택값을 sap.m.Table Binding Sorter로 변환한다.
         */
        onRfqHeaderTableSettingsConfirm(oEvent) {
            const oSortItem = oEvent.getParameter("sortItem");
            const oGroupItem = oEvent.getParameter("groupItem");
            const sSortKey = oSortItem && oSortItem.getKey();
            const sGroupKey = oGroupItem && oGroupItem.getKey();
            const bSortDescending = oEvent.getParameter("sortDescending");
            const bGroupDescending = oEvent.getParameter("groupDescending");

            this._applyHeaderTableSorters(sSortKey, bSortDescending, sGroupKey, bGroupDescending);
        },

        /**
         * RFQ Header Table의 정렬/그룹만 초기화한다.
         *
         * 조회조건과 조회 결과는 유지하고, 사용자가 바꾼 Table 표시 방식만 원복한다.
         */
        onResetRfqHeaderTableSettings() {
            this._resetHeaderTableSettings();
            this._showToast(this._getText("msgTableSettingsResetDone") || "정렬/그룹 조건을 초기화했습니다.");
        },

        /**
         * 상세조건 열기/닫기 버튼 이벤트.
         *
         * 버튼 문구는 XML의 expression binding이 `view>/AdvancedFilterVisible` 값을 보고
         * "상세조건" 또는 "상세조건 닫기"로 자동 전환한다.
         */
        onToggleAdvancedFilter() {
            const oViewModel = this.getView().getModel("view");
            const bVisible = oViewModel.getProperty("/AdvancedFilterVisible");

            oViewModel.setProperty("/AdvancedFilterVisible", !bVisible);
        },

        /**
         * RFQ Header 선택 이벤트.
         *
         * Begin Column의 RFQ Header 행을 선택하면 Mid Column을 열고,
         * 선택한 Header를 Mid 영역의 ObjectPage Header에 바인딩한 뒤 RFQItemSet을 조회한다.
         */
        onRfqSelectionChange(oEvent) {
            const oSelectedRfq = this._getSelectedObjectFromEvent(oEvent);

            if (!oSelectedRfq) {
                return;
            }

            return this._openMidColumnForRfq(oSelectedRfq);
        },

        /**
         * Mid Column을 전체 화면으로 확장한다.
         *
         * SAPUI5 FlexibleColumnLayout은 문자열 레이아웃 값을 기준으로 컬럼 표시 방식을 바꾼다.
         * `MidColumnFullScreen`은 SDK 샘플의 full-screen 버튼과 같은 의미로,
         * 선택한 RFQ의 비교 영역을 넓게 확인해야 할 때 사용한다.
         */
        onEnterMidFullScreen() {
            this._setFclLayout("MidColumnFullScreen");
        },

        /**
         * Mid Column 전체 화면을 해제하고 Begin + Mid 2컬럼 비교 화면으로 돌아간다.
         *
         * RFQ 목록과 상세 비교를 동시에 보는 것이 이 프로그램의 기본 작업 흐름이므로
         * 전체 화면 해제 시에는 `TwoColumnsMidExpanded`로 복귀시킨다.
         */
        onExitMidFullScreen() {
            this._setFclLayout("TwoColumnsMidExpanded");
        },

        /**
         * Mid Column을 닫고 선택된 RFQ 및 비교 영역을 초기화한다.
         *
         * 닫기 버튼은 화면 배치만 바꾸는 것이 아니라, 사용자가 더 이상 선택 RFQ를 보고 있지 않다는 뜻이다.
         * 따라서 기존 `_clearSelectionAndComparisonArea`를 재사용해 Header 선택, RFQ Item, MQ 비교 데이터까지 함께 비운다.
         */
        onCloseMidColumn() {
            this._clearSelectionAndComparisonArea();
        },

        /**
         * RFQ Item 선택 이벤트.
         *
         * 선택된 RFQ Item을 work 모델에 보관하고 이전 Item의 MQ 선택/비교표/차트 데이터를 초기화한다.
         * 그 다음 Backend가 계산한 MQ 후보 비교 결과를 MQCompareSet에서 조회한다.
         */
        onRfqItemSelectionChange(oEvent) {
            const oSelectedItem = this._getSelectedObjectFromEvent(oEvent);
            const oWorkModel = this.getView().getModel("work");

            if (!oSelectedItem || !oWorkModel) {
                return Promise.resolve([]);
            }

            oWorkModel.setProperty("/SelectedRfqItem", oSelectedItem);
            oWorkModel.setProperty("/SelectedMq", {});
            oWorkModel.setProperty("/MqCompareRows", []);
            oWorkModel.setProperty("/ChartRows", []);

            return this._loadMqCompareForRfqItem(oSelectedItem);
        },

        /**
         * MQ 비교표 RadioButton 선택 이벤트.
         *
         * sap.ui.table.Table의 행 컨텍스트 처리와 단일 선택 제어는 MQ 비교 기능 구현 단계에서 작성한다.
         */
        onMqRadioSelect(oEvent) {
            const oSelectedRow = this._getObjectFromEventSource(oEvent);

            if (!oSelectedRow || oSelectedRow.CanSelect !== "X") {
                return;
            }

            this._setSelectedMq(oSelectedRow);
        },

        /**
         * 자동추천 적용 버튼 이벤트.
         *
         * 설계서 기준으로 자동추천은 UI5에서 가격/납기 조건을 다시 계산하지 않는다.
         * Backend가 계산해서 내려준 RecommendYn과 CanSelect만 신뢰한다.
         *
         * RecommendYn = X 이더라도 이미 채택됐거나, 미응답이거나, PO 생성 등으로
         * CanSelect가 X가 아니면 채택 대상으로 자동 지정하지 않는다.
         */
        onApplyAutoRecommend() {
            const oRecommendedRow = this._findSelectableRecommendedMq();

            if (!oRecommendedRow) {
                this._showToast(this._getText("msgNoSelectableRecommend") || "선택 가능한 추천 MQ가 없습니다.");
                return;
            }

            this._setSelectedMq(oRecommendedRow);
        },

        /**
         * MQ 상세 Dialog 열기 이벤트.
         *
         * Fragment 로딩과 MQDetailSet 단건 조회는 상세 팝업 연결 단계에서 작성한다.
         */
        onOpenMqDetail() {
            const oSelectedMq = this.getView().getModel("work").getProperty("/SelectedMq");

            if (!oSelectedMq || !oSelectedMq.MqNo || !oSelectedMq.MqItem) {
                this._showToast(this._getText("msgSelectMq") || "채택할 MQ를 선택하세요.");
                return Promise.resolve(null);
            }

            return this._loadMqDetail(oSelectedMq.MqNo, oSelectedMq.MqItem);
        },

        onOpenMqDetailFromRow(oEvent) {
            const oRow = this._getObjectFromEventSource(oEvent);

            if (!oRow || !oRow.MqNo || !oRow.MqItem) {
                return Promise.resolve(null);
            }

            return this._loadMqDetail(oRow.MqNo, oRow.MqItem);
        },

        /**
         * 채택 버튼 이벤트.
         *
         * 선택된 MQ 1건을 현재 RFQ Item의 최종 거래선으로 채택한다.
         * 실제 기존 채택 MQ 해제와 신규 채택 처리는 Backend `QuotationItemSet_UPDATE_ENTITY`가
         * `ActionType = AWARD`를 기준으로 단건 트랜잭션에서 처리한다.
         */
        onSaveAward() {
            const oWorkModel = this.getView().getModel("work");
            const oSelectedMq = oWorkModel ? (oWorkModel.getProperty("/SelectedMq") || {}) : {};

            if (!oSelectedMq.MqNo || !oSelectedMq.MqItem) {
                this._showToast(this._getText("msgSelectMq") || "채택할 MQ를 선택하세요.");
                return Promise.resolve(null);
            }

            return this._confirmAction(this._getText("msgConfirmAward") || "선택한 MQ를 이 RFQ Item의 최종 거래선으로 채택하시겠습니까?")
                .then((bConfirmed) => {
                    if (!bConfirmed) {
                        return null;
                    }

                    return this._updateQuotationItem(
                        oSelectedMq.MqNo,
                        oSelectedMq.MqItem,
                        "AWARD",
                        this._getText("msgAwardSuccess") || "견적이 채택되었습니다."
                    );
                });
        },

        /**
         * 채택취소 버튼 이벤트.
         *
         * 채택취소는 현재 RFQ Item에 이미 채택된 MQ를 대상으로만 수행한다.
         * 화면 버튼도 `CanCancelAward = X`일 때만 활성화하지만, 사용자가 오래된 화면 상태에서
         * 버튼을 누르거나 테스트 코드가 직접 호출할 수 있으므로 Controller에서도 한 번 더 방어한다.
         *
         * Backend는 `ActionType = CANCEL`을 받으면 해당 MQ Item의 SELIDC를 해제하고,
         * PO 생성 여부 같은 업무 제약은 DPC_EXT에서 최종 검증한다.
         */
        onCancelAward() {
            const oWorkModel = this.getView().getModel("work");
            const oSelectedRfqItem = oWorkModel ? (oWorkModel.getProperty("/SelectedRfqItem") || {}) : {};
            const sAwardMqNo = oSelectedRfqItem.AwardMqNo;
            const sAwardMqItem = oSelectedRfqItem.AwardMqItem;

            if (oSelectedRfqItem.CanCancelAward !== "X" || !sAwardMqNo || !sAwardMqItem) {
                this._showToast(this._getText("msgNoAwardToCancel") || "채택취소할 MQ가 없습니다.");
                return Promise.resolve(null);
            }

            return this._confirmAction(this._getText("msgConfirmCancel") || "현재 채택된 MQ를 채택취소하시겠습니까?")
                .then((bConfirmed) => {
                    if (!bConfirmed) {
                        return null;
                    }

                    return this._updateQuotationItem(
                        sAwardMqNo,
                        sAwardMqItem,
                        "CANCEL",
                        this._getText("msgCancelSuccess") || "견적 채택이 취소되었습니다."
                    );
                });
        },

        /**
         * 상세 Dialog 안의 "이 MQ 선택" 버튼 이벤트.
         *
         * Dialog에서 MQ를 선택한 뒤 비교표의 선택 상태와 맞추는 로직은 상세 팝업 연결 단계에서 작성한다.
         */
        onSelectMqFromDialog() {
            const oDetailModel = this.getView().getModel("detail");
            const oMqDetail = oDetailModel ? (oDetailModel.getProperty("/MqDetail") || {}) : {};
            const oCompareRow = this._findMqCompareRow(oMqDetail.MqNo, oMqDetail.MqItem);

            /*
             * Dialog의 "이 MQ 선택"은 상세 조회가 아니라 채택 대상 지정 기능이다.
             * 따라서 UI에서 임의로 가능 여부를 재계산하지 않고, Backend가 내려준
             * MQ 비교 행의 CanSelect 값을 다시 확인한다.
             *
             * 이미 채택된 MQ, 미응답 MQ, PO 생성 MQ처럼 CanSelect가 X가 아닌 행은
             * 상세 조회만 허용하고 work>/SelectedMq는 덮어쓰지 않는다.
             */
            if (!oCompareRow || oCompareRow.CanSelect !== "X") {
                return;
            }

            this._setSelectedMq(oCompareRow);
            this.onCloseMqDetailDialog();
        },

        /**
         * 상세 Dialog 닫기 버튼 이벤트.
         *
         * 실제 Dialog close 처리는 Fragment 연결 단계에서 작성한다.
         */
        onCloseMqDetailDialog() {
            const oDialog = this.byId("idMqDetailDialog");

            if (oDialog && oDialog.close) {
                oDialog.close();
            }
        },

        /**
         * 비어 있는 이벤트 핸들러.
         *
         * XMLView가 먼저 안정적으로 렌더링되도록 임시로 남겨두는 안전장치다.
         */
        onPlaceholderAction() {
        },

        /**
         * RFQHeaderSet을 조회하여 Begin Column의 RFQ Header 목록, KPI, 건수를 갱신한다.
         *
         * SAPUI5 OData V2 Model의 `read`는 success/error 콜백 방식이다.
         * 이 화면에서는 조회 이후 여러 후속 처리가 이어지므로 `_readEntitySet`에서 Promise로 감싼 뒤
         * then/catch/finally 흐름으로 작성한다.
         */
        _loadRfqHeaders(mOptions = {}) {
            const oView = this.getView();
            const oViewModel = oView.getModel("view");
            const oWorkModel = oView.getModel("work");
            const aFilters = this._buildHeaderFilters();
            const bKeepComparisonContext = mOptions.keepComparisonContext === true;

            if (oViewModel) {
                oViewModel.setProperty("/Busy", true);
            }

            /*
             * 일반 조회는 이전 비교 컨텍스트를 지우지만, 채택 후 재조회는 사용자가 보던
             * Mid Column과 선택 RFQ Item을 유지해야 하므로 초기화를 건너뛴다.
             */
            if (!bKeepComparisonContext) {
                this._clearSelectionAndComparisonArea();
            }

            return this._readEntitySet("/RFQHeaderSet", aFilters).then((aRows) => {
                oWorkModel.setProperty("/RfqHeaders", aRows);
                this._applyHeaderQuickAwardStatusFilter("", true);
                this._updateHeaderKpis(aRows);
                this._reapplyHeaderTableSorters();

                if (!bKeepComparisonContext && aRows.length === 1) {
                    /*
                     * RFQ 번호로 1건만 조회된 경우에는 사용자가 목록을 다시 누르지 않아도 Mid Column을 연다.
                     * Header 조회 자체는 성공으로 유지해야 하므로, Item 조회 실패는 RFQHeaderSet catch로 전파하지 않는다.
                     */
                    this._openMidColumnForRfq(aRows[0]).catch(() => {});
                }

                return aRows;
            }).catch((oError) => {
                oWorkModel.setProperty("/RfqHeaders", []);
                this._applyHeaderQuickAwardStatusFilter("", true);
                this._updateHeaderKpis([]);
                this._showToast(this._getText("msgLoadRfqHeaderError") || "RFQ Header 조회 중 오류가 발생했습니다.");
                throw oError;
            }).finally(() => {
                if (oViewModel) {
                    oViewModel.setProperty("/Busy", false);
                }
            });
        },

        /**
         * 조회조건 JSONModel 값을 Gateway가 이해할 수 있는 OData Filter 배열로 변환한다.
         *
         * Backend DPC_EXT의 GET_FILTER_VALUES는 Metadata 기준 CamelCase Property명을 읽는다.
         * 따라서 ABAP 필드명(RFQ_NO, DOC_DATE)이 아니라 OData Property명(RfqNo, DocDate)을 사용한다.
         */
        _buildHeaderFilters() {
            const oFilterModel = this.getView().getModel("filter");
            const oFilter = oFilterModel ? oFilterModel.getData() : {};
            const aFilters = [];

            this._addTextFilter(aFilters, "RfqNo", oFilter.RfqNo, FilterOperator.EQ);
            this._addDateFilter(aFilters, "DocDate", FilterOperator.GE, oFilter.DocDateFrom);
            this._addDateFilter(aFilters, "DocDate", FilterOperator.LE, oFilter.DocDateTo);
            this._addTextFilter(aFilters, "Lifnr", oFilter.Lifnr, FilterOperator.EQ);
            this._addTextFilter(aFilters, "Name1", oFilter.Name1, FilterOperator.Contains);
            this._addTextFilter(aFilters, "Matnr", oFilter.Matnr, FilterOperator.EQ);
            this._addTextFilter(aFilters, "Maktx", oFilter.Maktx, FilterOperator.Contains);
            this._addTextFilter(aFilters, "Werks", oFilter.Werks, FilterOperator.EQ);
            this._addDateFilter(aFilters, "Eindt", FilterOperator.GE, oFilter.EindtFrom);
            this._addDateFilter(aFilters, "Eindt", FilterOperator.LE, oFilter.EindtTo);
            this._addTextFilter(aFilters, "MqNo", oFilter.MqNo, FilterOperator.EQ);
            this._addTextFilter(aFilters, "Bukrs", oFilter.Bukrs, FilterOperator.EQ);
            this._addTextFilter(aFilters, "Ekorg", oFilter.Ekorg, FilterOperator.EQ);
            this._addTextFilter(aFilters, "Ekgrp", oFilter.Ekgrp, FilterOperator.EQ);
            this._addAwardStatusFilters(aFilters, oFilter.AwardStatus);

            return aFilters;
        },

        /**
         * 문자열 조건을 Filter 배열에 추가한다.
         *
         * 빈 값은 조회조건이 아니므로 Filter를 만들지 않는다.
         * 공급업체명/자재명은 설계서 기준으로 부분 검색 성격이 있어 Contains를 사용하고,
         * 코드성 필드는 정확히 일치해야 하므로 EQ를 사용한다.
         */
        _addTextFilter(aFilters, sProperty, sValue, sOperator) {
            const sCleanValue = typeof sValue === "string" ? sValue.trim() : sValue;

            if (sCleanValue) {
                aFilters.push(new Filter(sProperty, sOperator, sCleanValue));
            }
        },

        /**
         * 선택 RFQ의 RFQItemSet을 조회한다.
         *
         * Backend DPC_EXT의 RFQITEMSET_GET_ENTITYSET은 `RfqNo eq '...'` 조건을 기준으로
         * 해당 RFQ의 품목과 품목별 채택상태, 채택 MQ, 채택취소 가능 여부를 계산해서 내려준다.
         * UI5에서는 이 계산 결과를 그대로 `work>/RfqItems`에 담고, 이후 RFQ Item 선택 시 MQCompareSet을 이어서 조회한다.
         */
        _loadRfqItemsForRfq(sRfqNo) {
            const oWorkModel = this.getView().getModel("work");
            const aFilters = this._buildRfqItemFilters(sRfqNo);

            this._clearRfqItemDependentArea();

            if (!sRfqNo) {
                return Promise.resolve([]);
            }

            return this._readEntitySet("/RFQItemSet", aFilters).then((aRows) => {
                if (oWorkModel) {
                    oWorkModel.setProperty("/RfqItems", aRows);
                }

                return aRows;
            }).catch((oError) => {
                if (oWorkModel) {
                    oWorkModel.setProperty("/RfqItems", []);
                }

                this._showToast(this._getText("msgLoadRfqItemError") || "RFQ Item 목록 조회 중 오류가 발생했습니다.");
                throw oError;
            });
        },

        /**
         * RFQItemSet 조회용 OData Filter를 만든다.
         *
         * DPC_EXT의 필터 해석 메서드는 OData Property명 기준으로 `RfqNo`를 읽는다.
         * 따라서 화면에서 선택한 Header의 RfqNo를 그대로 EQ 조건으로 전달한다.
         */
        _buildRfqItemFilters(sRfqNo) {
            const aFilters = [];

            this._addTextFilter(aFilters, "RfqNo", sRfqNo, FilterOperator.EQ);

            return aFilters;
        },

        /**
         * 선택 RFQ Item의 MQCompareSet을 조회한다.
         *
         * DPC_EXT는 RFQ 번호와 RFQ Item 번호를 함께 받아야 후보 MQ를 정확히 비교할 수 있다.
         * 조회된 Row에는 RadioButton 바인딩용 UI 전용 필드 `UiSelected`를 false로 추가한다.
         * 실제 선택 가능 여부는 Backend의 `CanSelect`를 그대로 사용하고, 여기서는 자동 선택하지 않는다.
         */
        _loadMqCompareForRfqItem(oRfqItem) {
            const oView = this.getView();
            const oWorkModel = oView.getModel("work");
            const oSelectedRfq = oWorkModel ? (oWorkModel.getProperty("/SelectedRfq") || {}) : {};
            const sRfqNo = oRfqItem && (oRfqItem.RfqNo || oSelectedRfq.RfqNo);
            const sRfqItem = oRfqItem && oRfqItem.RfqItem;
            const aFilters = this._buildMqCompareFilters(sRfqNo, sRfqItem);

            if (!sRfqNo || !sRfqItem) {
                return Promise.resolve([]);
            }

            return this._readEntitySet("/MQCompareSet", aFilters).then((aRows) => {
                const aPreparedRows = (aRows || []).map((oRow) => Object.assign({}, oRow, {
                    UiSelected: false
                }));

                if (oWorkModel) {
                    oWorkModel.setProperty("/MqCompareRows", aPreparedRows);
                    oWorkModel.setProperty("/ChartRows", this._prepareChartRows(aPreparedRows));
                }

                return aPreparedRows;
            }).catch((oError) => {
                if (oWorkModel) {
                    oWorkModel.setProperty("/MqCompareRows", []);
                    oWorkModel.setProperty("/ChartRows", []);
                }

                this._showToast(this._getText("msgLoadMqCompareError") || "MQ 비교 목록 조회 중 오류가 발생했습니다.");
                throw oError;
            });
        },

        /**
         * MQCompareSet 조회용 필터를 만든다.
         *
         * Backend 필터 해석 기준에 맞춰 `RfqNo eq ...`와 `RfqItem eq ...`를 모두 전달한다.
         */
        _buildMqCompareFilters(sRfqNo, sRfqItem) {
            const aFilters = [];

            this._addTextFilter(aFilters, "RfqNo", sRfqNo, FilterOperator.EQ);
            this._addTextFilter(aFilters, "RfqItem", sRfqItem, FilterOperator.EQ);

            return aFilters;
        },

        _prepareChartRows(aRows) {
            return (aRows || []).reduce((aChartRows, oRow) => {
                const iNetwrKrw = Number(oRow && oRow.NetwrKrw);

                if (!oRow || oRow.ResponseStatus === "N" || !Number.isFinite(iNetwrKrw) || iNetwrKrw <= 0) {
                    return aChartRows;
                }

                aChartRows.push({
                    RfqNo: oRow.RfqNo,
                    RfqItem: oRow.RfqItem,
                    MqNo: oRow.MqNo,
                    MqItem: oRow.MqItem,
                    Name1: oRow.Name1 || oRow.MqNo,
                    NetwrKrw: iNetwrKrw,
                    RecommendYn: oRow.RecommendYn,
                    CurrentAwardYn: oRow.CurrentAwardYn
                });

                return aChartRows;
            }, []);
        },

        _setSelectedMq(oSelectedRow) {
            const oWorkModel = this.getView().getModel("work");
            const sMqNo = oSelectedRow && oSelectedRow.MqNo;
            const sMqItem = oSelectedRow && oSelectedRow.MqItem;

            if (!oWorkModel || !sMqNo || !sMqItem) {
                return;
            }

            const aUpdatedRows = (oWorkModel.getProperty("/MqCompareRows") || []).map((oRow) => {
                return Object.assign({}, oRow, {
                    UiSelected: oRow.MqNo === sMqNo && oRow.MqItem === sMqItem
                });
            });
            const oSelectedFromRows = aUpdatedRows.find((oRow) => {
                return oRow.MqNo === sMqNo && oRow.MqItem === sMqItem;
            }) || oSelectedRow;

            oWorkModel.setProperty("/MqCompareRows", aUpdatedRows);
            oWorkModel.setProperty("/SelectedMq", {
                RfqNo: oSelectedFromRows.RfqNo,
                RfqItem: oSelectedFromRows.RfqItem,
                MqNo: oSelectedFromRows.MqNo,
                MqItem: oSelectedFromRows.MqItem,
                Lifnr: oSelectedFromRows.Lifnr,
                Name1: oSelectedFromRows.Name1,
                CanSelect: oSelectedFromRows.CanSelect,
                BlockReason: oSelectedFromRows.BlockReason,
                RecommendYn: oSelectedFromRows.RecommendYn,
                CurrentAwardYn: oSelectedFromRows.CurrentAwardYn
            });
        },

        _findMqCompareRow(sMqNo, sMqItem) {
            const oWorkModel = this.getView().getModel("work");
            const aRows = oWorkModel ? (oWorkModel.getProperty("/MqCompareRows") || []) : [];

            if (!sMqNo || !sMqItem) {
                return null;
            }

            return aRows.find((oRow) => {
                return oRow.MqNo === sMqNo && oRow.MqItem === sMqItem;
            }) || null;
        },

        _findSelectableRecommendedMq() {
            const oWorkModel = this.getView().getModel("work");
            const aRows = oWorkModel ? (oWorkModel.getProperty("/MqCompareRows") || []) : [];

            return aRows.find((oRow) => {
                return oRow.RecommendYn === "X" && oRow.CanSelect === "X";
            }) || null;
        },

        /**
         * RFQ Header sap.m.Table에 정렬/그룹 Sorter를 적용한다.
         *
         * SAPUI5 Table/List 정렬은 별도 테이블 데이터를 다시 만들지 않고,
         * Binding에 Sorter 배열을 전달하는 방식으로 처리한다.
         */
        /**
         * KPI 카드로 선택한 채택상태를 RFQ Header Table에만 적용한다.
         *
         * 중요:
         * - 이 필터는 DynamicPage Header의 조회조건(`filter` 모델)을 바꾸지 않는다.
         * - 따라서 KPI 숫자는 마지막 조회 버튼으로 읽어온 RFQHeaderSet 결과 기준을 유지한다.
         * - 화면 목록만 좁혀 보여주기 위해 sap.m.Table의 items binding에 Application filter를 건다.
         */
        _applyHeaderQuickAwardStatusFilter(sAwardStatus, bSuppressToast) {
            const oView = this.getView();
            const oViewModel = oView.getModel("view");
            const oTable = this.byId("idRfqHeaderTable");
            const oBinding = oTable && oTable.getBinding && oTable.getBinding("items");
            const aTableFilters = sAwardStatus ? [
                new Filter("AwardStatus", FilterOperator.EQ, sAwardStatus)
            ] : [];

            if (oViewModel) {
                oViewModel.setProperty("/HeaderTableQuickAwardStatus", sAwardStatus || "");
            }

            if (oBinding && typeof oBinding.filter === "function") {
                oBinding.filter(aTableFilters, "Application");
            }

            this._updateRfqHeaderCountForQuickFilter(sAwardStatus);
            this._updateHeaderTableStateSummary();

            return bSuppressToast === true ? null : aTableFilters;
        },

        /**
         * RFQ Header 목록 제목의 (N)은 현재 화면에 보이는 목록 건수를 의미한다.
         *
         * KPI 숫자는 조회 결과 기준으로 유지하지만, 테이블 제목은 사용자가 보고 있는
         * 목록의 건수와 맞아야 하므로 빠른 필터가 있으면 해당 상태만 다시 센다.
         */
        _updateRfqHeaderCountForQuickFilter(sAwardStatus) {
            const oWorkModel = this.getView().getModel("work");
            const aRows = oWorkModel ? (oWorkModel.getProperty("/RfqHeaders") || []) : [];
            const iCount = sAwardStatus
                ? aRows.filter((oRow) => oRow && oRow.AwardStatus === sAwardStatus).length
                : aRows.length;

            if (oWorkModel) {
                oWorkModel.setProperty("/RfqHeaderCount", iCount);
            }
        },

        _applyHeaderTableSorters(sSortKey, bSortDescending, sGroupKey, bGroupDescending) {
            const oTable = this.byId("idRfqHeaderTable");
            const oBinding = oTable && oTable.getBinding && oTable.getBinding("items");
            const aSorters = [];

            this._setHeaderTableSortGroupState(sSortKey, bSortDescending, sGroupKey, bGroupDescending);

            if (!oBinding) {
                return;
            }

            if (sGroupKey) {
                /*
                 * 그룹 Sorter는 배열의 첫 번째에 둔다.
                 * 그래야 같은 그룹이 먼저 모이고, 그 안에서 별도 정렬 조건이 적용된다.
                 */
                aSorters.push(this._createHeaderTableSorter(
                    sGroupKey,
                    bGroupDescending,
                    this._getHeaderTableGroup.bind(this, sGroupKey)
                ));
            }

            if (sSortKey && sSortKey !== sGroupKey) {
                aSorters.push(this._createHeaderTableSorter(sSortKey, bSortDescending));
            }

            oBinding.sort(aSorters);
        },

        _reapplyHeaderTableSorters() {
            const oViewModel = this.getView().getModel("view");

            if (!oViewModel) {
                return;
            }

            this._applyHeaderTableSorters(
                oViewModel.getProperty("/HeaderTableSortKey"),
                oViewModel.getProperty("/HeaderTableSortDescending"),
                oViewModel.getProperty("/HeaderTableGroupKey"),
                oViewModel.getProperty("/HeaderTableGroupDescending")
            );
        },

        _resetHeaderTableSettings() {
            this._applyHeaderTableSorters("", false, "", false);
            this._resetHeaderTableSettingsDialog();
        },

        _resetHeaderTableSettingsDialog() {
            const oDialog = this.byId("idRfqHeaderTableSettingsDialog");

            if (!oDialog) {
                return;
            }

            if (typeof oDialog.setSortDescending === "function") {
                oDialog.setSortDescending(false);
            }

            if (typeof oDialog.setGroupDescending === "function") {
                oDialog.setGroupDescending(false);
            }

            this._clearViewSettingsItems(oDialog.getSortItems && oDialog.getSortItems());
            this._clearViewSettingsItems(oDialog.getGroupItems && oDialog.getGroupItems());
        },

        _clearViewSettingsItems(aItems) {
            (aItems || []).forEach((oItem) => {
                if (oItem && typeof oItem.setSelected === "function") {
                    oItem.setSelected(false);
                }
            });
        },

        _createHeaderTableSorter(sKey, bDescending, vGroup) {
            /*
             * Gateway Decimal/Integer가 문자열로 들어올 수 있는 필드는 숫자 comparator를 사용한다.
             * 예: "10"과 "2"를 문자열 비교하면 10이 2보다 앞서는 문제가 생길 수 있다.
             */
            const fnComparator = this._isHeaderNumericSortKey(sKey) ? this._compareNumericValues.bind(this) : undefined;

            return new Sorter(sKey, bDescending, vGroup, fnComparator);
        },

        _isHeaderNumericSortKey(sKey) {
            return [
                "RfqItemCount",
                "MqCount",
                "VendorCount",
                "AwardItemCount",
                "PoItemCount"
            ].indexOf(sKey) > -1;
        },

        _compareNumericValues(vA, vB) {
            let fA = Number(vA);
            let fB = Number(vB);

            if (Number.isNaN(fA)) {
                fA = 0;
            }

            if (Number.isNaN(fB)) {
                fB = 0;
            }

            if (fA < fB) {
                return -1;
            }

            if (fA > fB) {
                return 1;
            }

            return 0;
        },

        _getHeaderTableGroup(sProperty, oContext) {
            const oRow = oContext && oContext.getObject ? oContext.getObject() : {};
            let sKey = oRow[sProperty] || "";
            let sText = sKey || this._getText("notAvailable") || "N/A";

            if (sProperty === "AwardStatus") {
                sText = oRow.AwardStatusText || this._getAwardStatusTextByCode(sKey);
            } else if (sProperty === "DocDate") {
                sText = formatter.formatDate(oRow.DocDate);
                sKey = sText;
            } else if (sProperty === "Bukrs" && oRow.Butxt) {
                sText = sKey + " - " + oRow.Butxt;
            } else if (sProperty === "Ekorg" && oRow.Ekotx) {
                sText = sKey + " - " + oRow.Ekotx;
            } else if (sProperty === "Ekgrp" && oRow.Eknam) {
                sText = sKey + " - " + oRow.Eknam;
            }

            return {
                key: sKey,
                text: this._getHeaderTableSettingLabel(sProperty) + ": " + (sText || this._getText("notAvailable") || "N/A")
            };
        },

        _setHeaderTableSortGroupState(sSortKey, bSortDescending, sGroupKey, bGroupDescending) {
            const oViewModel = this.getView().getModel("view");

            if (!oViewModel) {
                return;
            }

            oViewModel.setProperty("/HeaderTableSortKey", sSortKey || "");
            oViewModel.setProperty("/HeaderTableSortDescending", !!bSortDescending);
            oViewModel.setProperty("/HeaderTableGroupKey", sGroupKey || "");
            oViewModel.setProperty("/HeaderTableGroupDescending", !!bGroupDescending);

            this._updateHeaderTableStateSummary();
        },

        _updateHeaderTableStateSummary() {
            const oViewModel = this.getView().getModel("view");

            if (!oViewModel) {
                return;
            }

            oViewModel.setProperty("/HeaderTableStatusSummary", this._getHeaderTableStatusSummary());
            oViewModel.setProperty("/HeaderTableSortGroupSummary", this._getHeaderTableSortGroupSummary());
        },

        _getHeaderTableStatusSummary() {
            const oViewModel = this.getView().getModel("view");
            const oFilterModel = this.getView().getModel("filter");
            const sQuickAwardStatus = oViewModel && oViewModel.getProperty("/HeaderTableQuickAwardStatus");
            const aAwardStatus = oFilterModel ? (oFilterModel.getProperty("/AwardStatus") || []) : [];

            if (sQuickAwardStatus) {
                return (this._getText("tableStatusSummaryPrefix") || "상태")
                    + ": "
                    + this._getAwardStatusTextByCode(sQuickAwardStatus);
            }

            if (!aAwardStatus.length) {
                return this._getText("tableStatusSummaryAll") || "상태: 전체";
            }

            return (this._getText("tableStatusSummaryPrefix") || "상태")
                + ": "
                + aAwardStatus.map((sStatus) => this._getAwardStatusTextByCode(sStatus)).filter(Boolean).join(", ");
        },

        _getHeaderTableSortGroupSummary() {
            const oViewModel = this.getView().getModel("view");
            const aParts = [];
            const sSortKey = oViewModel && oViewModel.getProperty("/HeaderTableSortKey");
            const sGroupKey = oViewModel && oViewModel.getProperty("/HeaderTableGroupKey");

            if (sSortKey) {
                aParts.push(
                    (this._getText("tableSortSummaryPrefix") || "정렬")
                    + ": "
                    + this._getHeaderTableSettingLabel(sSortKey)
                    + " "
                    + this._getOrderText(oViewModel.getProperty("/HeaderTableSortDescending"))
                );
            }

            if (sGroupKey) {
                aParts.push(
                    (this._getText("tableGroupSummaryPrefix") || "그룹")
                    + ": "
                    + this._getHeaderTableSettingLabel(sGroupKey)
                    + " "
                    + this._getOrderText(oViewModel.getProperty("/HeaderTableGroupDescending"))
                );
            }

            return aParts.length ? aParts.join(" / ") : (this._getText("tableSortGroupSummaryDefault") || "정렬/그룹: 기본");
        },

        _getHeaderTableSettingLabel(sKey) {
            const mLabelKeyByProperty = {
                RfqNo: "rfqNo",
                DocDate: "docDate",
                RfqItemCount: "rfqItemCount",
                MqCount: "mqCount",
                VendorCount: "vendorCount",
                AwardStatus: "awardStatus",
                Bukrs: "bukrs",
                Ekorg: "ekorg",
                Ekgrp: "ekgrp"
            };

            return mLabelKeyByProperty[sKey] ? this._getText(mLabelKeyByProperty[sKey]) : sKey;
        },

        _getOrderText(bDescending) {
            return bDescending ? (this._getText("sortDescending") || "내림차순") : (this._getText("sortAscending") || "오름차순");
        },

        _getAwardStatusTextByCode(sStatus) {
            const mTextKeyByStatus = {
                N: "awardStatusN",
                P: "awardStatusP",
                A: "awardStatusA",
                PO: "awardStatusPO"
            };

            return mTextKeyByStatus[sStatus] ? this._getText(mTextKeyByStatus[sStatus]) : sStatus;
        },

        /**
         * RFQ Item 하위 단계의 선택/비교 데이터를 비운다.
         *
         * Header를 바꿔 선택하면 이전 Header의 Item, MQ 후보, 차트가 남아 있으면 안 된다.
         * Header 자체와 Begin 목록은 유지하고, Mid Column 안쪽의 하위 업무 데이터만 초기화한다.
         */
        _clearRfqItemDependentArea() {
            const oWorkModel = this.getView().getModel("work");

            this._clearTableSelection("idRfqItemTable");

            if (oWorkModel) {
                oWorkModel.setProperty("/RfqItems", []);
                oWorkModel.setProperty("/SelectedRfqItem", {});
                oWorkModel.setProperty("/SelectedMq", {});
                oWorkModel.setProperty("/MqCompareRows", []);
                oWorkModel.setProperty("/ChartRows", []);
            }
        },

        /**
         * 날짜 조건을 Filter 배열에 추가한다.
         *
         * OData V2의 Edm.DateTime 필터는 Date 객체를 넘기면 UI5 ODataModel이 직렬화한다.
         * 자정 값을 그대로 쓰면 브라우저/서버 시간대 차이로 전날이 될 수 있으므로,
         * 납기지연 조회 프로그램과 동일하게 날짜 전용 조건은 정오 기준 Date로 보정한다.
         */
        _addDateFilter(aFilters, sProperty, sOperator, oDate) {
            if (oDate instanceof Date && !Number.isNaN(oDate.getTime())) {
                aFilters.push(new Filter(sProperty, sOperator, this._normalizeDate(oDate)));
            }
        },

        /**
         * MultiComboBox의 채택상태 선택값을 OR Filter로 변환한다.
         *
         * 예: 미채택(N), 일부채택(P)을 같이 선택하면
         * `(AwardStatus eq 'N' or AwardStatus eq 'P')` 형태로 Gateway에 전달된다.
         */
        _addAwardStatusFilters(aFilters, aAwardStatus) {
            const aStatusKeys = Array.isArray(aAwardStatus) ? aAwardStatus.filter(Boolean) : [];

            if (!aStatusKeys.length) {
                return;
            }

            aFilters.push(new Filter({
                filters: aStatusKeys.map((sStatus) => {
                    return new Filter("AwardStatus", FilterOperator.EQ, sStatus);
                }),
                and: false
            }));
        },

        /**
         * SAPUI5 OData V2 Model의 read 호출을 Promise 형태로 감싼다.
         *
         * OData 응답은 보통 `{ results: [...] }` 형태로 내려오므로 배열만 반환한다.
         * 단건 응답이 들어오더라도 이 함수는 EntitySet 조회 전용이므로 빈 배열로 방어한다.
         */
        _readEntitySet(sPath, aFilters) {
            const oModel = this.getOwnerComponent().getModel();

            return new Promise((resolve, reject) => {
                if (!oModel || !oModel.read) {
                    reject(new Error("Default ODataModel is not available."));
                    return;
                }

                oModel.read(sPath, {
                    filters: aFilters || [],
                    success: (oData) => {
                        resolve(oData && Array.isArray(oData.results) ? oData.results : []);
                    },
                    error: reject
                });
            });
        },

        _readEntity(sPath) {
            const oModel = this.getOwnerComponent().getModel();

            return new Promise((resolve, reject) => {
                if (!oModel || !oModel.read) {
                    reject(new Error("Default ODataModel is not available."));
                    return;
                }

                oModel.read(sPath, {
                    success: (oData) => {
                        resolve(oData || {});
                    },
                    error: reject
                });
            });
        },

        _updateEntity(sPath, oPayload, mParameters) {
            const oModel = this.getOwnerComponent().getModel();

            return new Promise((resolve, reject) => {
                if (!oModel || !oModel.update) {
                    reject(new Error("Default ODataModel update is not available."));
                    return;
                }

                oModel.update(sPath, oPayload, Object.assign({}, mParameters, {
                    success: resolve,
                    error: reject
                }));
            });
        },

        _confirmAction(sMessage) {
            return new Promise((resolve) => {
                MessageBox.confirm(sMessage, {
                    onClose: (sAction) => {
                        resolve(sAction === MessageBox.Action.OK);
                    }
                });
            });
        },

        _updateQuotationItem(sMqNo, sMqItem, sActionType, sSuccessMessage) {
            const oViewModel = this.getView().getModel("view");
            const sPath = this._createQuotationItemPath(sMqNo, sMqItem);
            const oPayload = {
                MqNo: sMqNo,
                MqItem: sMqItem,
                ActionType: sActionType
            };

            if (!sPath) {
                return Promise.resolve(null);
            }

            if (oViewModel) {
                oViewModel.setProperty("/Busy", true);
            }

            /*
             * 설계서 기준 채택/취소는 Function Import가 아니라 QuotationItemSet 단건 MERGE다.
             * Gateway가 성공 시 204 No Content를 줄 수 있으므로 success body에 의존하지 않고,
             * 성공 callback 자체를 기준으로 메시지와 재조회를 처리한다.
             */
            return this._updateEntity(sPath, oPayload, {
                merge: true
            }).then(() => {
                this._showToast(sSuccessMessage);
                return this._refreshAfterAward();
            }).catch((oError) => {
                this._showToast(this._getText("msgDefaultError") || "처리 중 오류가 발생했습니다. 잠시 후 다시 시도하세요.");
                throw oError;
            }).finally(() => {
                if (oViewModel) {
                    oViewModel.setProperty("/Busy", false);
                }
            });
        },

        _createQuotationItemPath(sMqNo, sMqItem) {
            const oModel = this.getOwnerComponent().getModel();

            if (!sMqNo || !sMqItem) {
                return "";
            }

            if (oModel && oModel.createKey) {
                return oModel.createKey("/QuotationItemSet", {
                    MqNo: sMqNo,
                    MqItem: sMqItem
                });
            }

            return "/QuotationItemSet(MqNo='" + this._escapeODataKeyValue(sMqNo) + "',MqItem='" + this._escapeODataKeyValue(sMqItem) + "')";
        },

        _refreshAfterAward() {
            const oView = this.getView();
            const oViewModel = oView.getModel("view");
            const oWorkModel = oView.getModel("work");
            const oSelectedRfq = oWorkModel ? (oWorkModel.getProperty("/SelectedRfq") || {}) : {};
            const oSelectedRfqItem = oWorkModel ? (oWorkModel.getProperty("/SelectedRfqItem") || {}) : {};
            const sCurrentLayout = oViewModel ? oViewModel.getProperty("/FclLayout") : "";
            const sRfqNo = oSelectedRfqItem.RfqNo || oSelectedRfq.RfqNo;
            const sRfqItem = oSelectedRfqItem.RfqItem;

            /*
             * 채택 성공 후에는 Header KPI, Item 상태/채택 공급업체, MQ 비교 상태가 모두 바뀔 수 있다.
             * 따라서 Header -> Item -> MQ 순서로 다시 읽는다. Item 재조회 중 하위 영역이 초기화되므로,
             * 기존에 사용자가 보고 있던 RFQ와 RFQ Item 컨텍스트는 다시 세팅한 뒤 MQCompareSet을 호출한다.
             */
            return this._loadRfqHeaders({
                keepComparisonContext: true
            }).then(() => {
                if (!sRfqNo) {
                    return null;
                }

                if (oWorkModel) {
                    oWorkModel.setProperty("/SelectedRfq", oSelectedRfq);
                }

                return this._loadRfqItemsForRfq(sRfqNo).then((aItems) => {
                    const oUpdatedItem = (aItems || []).find((oItem) => {
                        return oItem.RfqItem === sRfqItem;
                    }) || oSelectedRfqItem;

                    if (oWorkModel) {
                        oWorkModel.setProperty("/SelectedRfq", oSelectedRfq);
                        oWorkModel.setProperty("/SelectedRfqItem", oUpdatedItem || {});
                    }

                    if (!sRfqItem) {
                        return [];
                    }

                    return this._loadMqCompareForRfqItem(Object.assign({}, oUpdatedItem || {}, {
                        RfqNo: sRfqNo,
                        RfqItem: sRfqItem
                    })).then((aRows) => {
                        /*
                         * Header/Item/MQ를 다시 읽어도 저장 직전 사용자가 보고 있던 FCL 배치를 복원한다.
                         * 채택은 데이터 변경이지 화면 닫기가 아니므로 `onCloseMidColumn`의 OneColumn 초기화와 분리한다.
                         */
                        if (oViewModel && sCurrentLayout) {
                            oViewModel.setProperty("/FclLayout", sCurrentLayout);
                        }

                        return aRows;
                    });
                });
            });
        },

        _loadMqDetail(sMqNo, sMqItem) {
            const oView = this.getView();
            const oViewModel = oView.getModel("view");
            const oDetailModel = oView.getModel("detail");
            const sPath = this._createMqDetailPath(sMqNo, sMqItem);

            if (!sPath) {
                return Promise.resolve(null);
            }

            if (oViewModel) {
                oViewModel.setProperty("/Busy", true);
            }

            return this._readEntity(sPath).then((oData) => {
                if (oDetailModel) {
                    oDetailModel.setProperty("/MqDetail", oData || {});
                }

                return this._openMqDetailDialog().then(() => oData);
            }).catch((oError) => {
                if (oDetailModel) {
                    oDetailModel.setProperty("/MqDetail", {});
                }

                this._showToast(this._getText("msgLoadMqDetailError") || "MQ 상세정보 조회 중 오류가 발생했습니다.");
                throw oError;
            }).finally(() => {
                if (oViewModel) {
                    oViewModel.setProperty("/Busy", false);
                }
            });
        },

        _createMqDetailPath(sMqNo, sMqItem) {
            const oModel = this.getOwnerComponent().getModel();

            if (!sMqNo || !sMqItem) {
                return "";
            }

            if (oModel && oModel.createKey) {
                return oModel.createKey("/MQDetailSet", {
                    MqNo: sMqNo,
                    MqItem: sMqItem
                });
            }

            return "/MQDetailSet(MqNo='" + this._escapeODataKeyValue(sMqNo) + "',MqItem='" + this._escapeODataKeyValue(sMqItem) + "')";
        },

        _escapeODataKeyValue(sValue) {
            return String(sValue).replace(/'/g, "''");
        },

        _openMqDetailDialog() {
            const oView = this.getView();

            if (!this._pMqDetailDialog) {
                this._pMqDetailDialog = Fragment.load({
                    id: oView.getId(),
                    name: "code.d3.quotecomparison.fragment.MQDetailDialog",
                    controller: this
                }).then((oDialog) => {
                    oView.addDependent(oDialog);
                    return oDialog;
                });
            }

            return this._pMqDetailDialog.then((oDialog) => {
                oDialog.open();
                return oDialog;
            });
        },

        /**
         * RFQ Header 상태별 KPI를 계산한다.
         *
         * Backend가 Header별 AwardStatus를 이미 계산해서 내려주므로,
         * UI5에서는 조회 결과 배열을 순회하며 상태 코드별 건수만 세면 된다.
         */
        _updateHeaderKpis(aRows) {
            const oWorkModel = this.getView().getModel("work");
            const oKpi = {
                NotAwarded: 0,
                PartiallyAwarded: 0,
                Awarded: 0,
                PoCreated: 0
            };

            (aRows || []).forEach((oRow) => {
                switch (oRow.AwardStatus) {
                    case "N":
                        oKpi.NotAwarded += 1;
                        break;
                    case "P":
                        oKpi.PartiallyAwarded += 1;
                        break;
                    case "A":
                        oKpi.Awarded += 1;
                        break;
                    case "PO":
                        oKpi.PoCreated += 1;
                        break;
                    default:
                        break;
                }
            });

            if (oWorkModel) {
                oWorkModel.setProperty("/Kpi", oKpi);
            }
        },

        /**
         * 새 Header 조회 전에 하위 비교 영역을 초기화한다.
         *
         * RFQ Header를 다시 조회하면 이전 Header의 RFQ Item/MQ 후보가 남아 있으면 안 된다.
         * 따라서 Begin Column 목록은 조회 결과로 갱신하되, Mid Column 관련 선택값과 비교 데이터는 비운다.
         */
        _clearSelectionAndComparisonArea() {
            const oView = this.getView();
            const oViewModel = oView.getModel("view");
            const oWorkModel = oView.getModel("work");

            this._clearTableSelection("idRfqHeaderTable");
            this._clearTableSelection("idRfqItemTable");

            if (oViewModel) {
                oViewModel.setProperty("/FclLayout", "OneColumn");
            }

            if (oWorkModel) {
                oWorkModel.setProperty("/SelectedRfq", {});
                oWorkModel.setProperty("/SelectedRfqItem", {});
                oWorkModel.setProperty("/SelectedMq", {});
                oWorkModel.setProperty("/RfqItems", []);
                oWorkModel.setProperty("/MqCompareRows", []);
                oWorkModel.setProperty("/ChartRows", []);
            }
        },

        /**
         * FlexibleColumnLayout의 현재 배치를 변경한다.
         *
         * 레이아웃 변경은 여러 버튼에서 반복되므로 작은 헬퍼로 모아둔다.
         * 이렇게 해두면 이후 SemanticHelper를 도입하더라도 이 함수 안에서만 변경하면 된다.
         */
        _clearTableSelection(sTableId) {
            const oTable = this.byId(sTableId);

            if (oTable && oTable.removeSelections) {
                oTable.removeSelections(true);
            }
        },

        _setFclLayout(sLayout) {
            const oViewModel = this.getView().getModel("view");

            if (oViewModel) {
                oViewModel.setProperty("/FclLayout", sLayout);
            }
        },

        /**
         * 날짜만 의미 있는 조회조건을 정오 기준 Date로 보정한다.
         *
         * 이 방식은 날짜가 UTC 변환 과정에서 전날로 밀리는 문제를 줄이기 위한 실무 방어 코드다.
         */
        _normalizeDate(oDate) {
            return new Date(oDate.getFullYear(), oDate.getMonth(), oDate.getDate(), 12, 0, 0);
        },

        /**
         * i18n 텍스트를 읽는다.
         *
         * 테스트나 초기 렌더링 시점에 i18n 모델이 아직 없을 수 있으므로 방어적으로 빈 문자열을 반환한다.
         */
        _getText(sKey, aArgs) {
            const oI18nModel = this.getView().getModel("i18n");
            const oBundle = oI18nModel && oI18nModel.getResourceBundle && oI18nModel.getResourceBundle();

            return oBundle && oBundle.getText ? oBundle.getText(sKey, aArgs) : "";
        },

        /**
         * 사용자에게 짧은 처리 메시지를 표시한다.
         *
         * 조회 실패처럼 화면 전환이 필요 없는 오류는 MessageToast로 가볍게 알린다.
         * 상세한 오류 메시지 수집과 MessagePopover 연결은 후속 유효성/오류처리 단계에서 확장한다.
         */
        _showToast(sMessage) {
            if (sMessage) {
                MessageToast.show(sMessage);
            }
        },

        /**
         * sap.m.Table의 selectionChange 이벤트에서 선택된 행 객체를 꺼낸다.
         *
         * 이번 화면에서는 RFQ Header 목록과 RFQ Item 목록 모두 sap.m.Table을 사용한다.
         * 두 테이블의 선택 이벤트가 같은 형태이므로 공통 헬퍼로 분리해 둔다.
         */
        _getSelectedObjectFromEvent(oEvent) {
            let oListItem;
            let oContext;

            if (!oEvent || !oEvent.getParameter) {
                return null;
            }

            oListItem = oEvent.getParameter("listItem") || oEvent.getParameter("selectedItem");

            if (!oListItem || !oListItem.getBindingContext) {
                return null;
            }

            oContext = oListItem.getBindingContext("work") || oListItem.getBindingContext();

            if (!oContext || !oContext.getObject) {
                return null;
            }

            return oContext.getObject();
        },

        _getObjectFromEventSource(oEvent) {
            const oSource = oEvent && oEvent.getSource && oEvent.getSource();
            const oContext = oSource && oSource.getBindingContext &&
                (oSource.getBindingContext("work") || oSource.getBindingContext());

            if (!oContext || !oContext.getObject) {
                return null;
            }

            return oContext.getObject();
        },

        /**
         * 선택된 RFQ Header를 Mid Column의 Header 영역에 반영하고 FCL을 2컬럼으로 전환한다.
         *
         * Header 선택 직후 RFQItemSet까지 조회해 Mid 첫 섹션을 채운다.
         */
        _openMidColumnForRfq(oRfq) {
            const oView = this.getView();
            const oViewModel = oView.getModel("view");
            const oWorkModel = oView.getModel("work");

            if (oWorkModel) {
                oWorkModel.setProperty("/SelectedRfq", oRfq || {});
            }

            if (oViewModel) {
                oViewModel.setProperty("/FclLayout", "TwoColumnsMidExpanded");
            }

            return this._loadRfqItemsForRfq(oRfq && oRfq.RfqNo);
        },

        /**
         * RFQ Header 조회 결과가 1건뿐이면 Mid Column을 자동으로 연다.
         *
         * 사용자가 RFQ 번호를 정확히 넣어 1건만 조회한 경우에는 Begin 목록에서 다시 클릭하지 않아도
         * 바로 RFQ Item/MQ 비교 영역으로 이동하는 것이 자연스럽다.
         */
        _openMidColumnIfSingleHeader() {
            const oWorkModel = this.getView().getModel("work");
            const aRfqHeaders = oWorkModel ? (oWorkModel.getProperty("/RfqHeaders") || []) : [];

            this._updateRfqHeaderCountFromRows();

            if (aRfqHeaders.length === 1) {
                this._openMidColumnForRfq(aRfqHeaders[0]);
            }
        },

        /**
         * RFQ Header 목록 제목의 (N)을 갱신한다.
         *
         * sap.m.Table의 items 바인딩 자체에서도 count를 읽을 수 있지만,
         * OData 조회 후 Controller에서 명시적으로 건수를 세팅하면 KPI 계산과 같은 후속 로직에서도
         * 같은 값을 재사용할 수 있다.
         */
        _updateRfqHeaderCountFromRows() {
            const oWorkModel = this.getView().getModel("work");
            const aRfqHeaders = oWorkModel ? (oWorkModel.getProperty("/RfqHeaders") || []) : [];

            if (oWorkModel) {
                oWorkModel.setProperty("/RfqHeaderCount", aRfqHeaders.length);
            }
        }
    });
});
