## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Wed Mar 04 2026 04:46:36 GMT+0900 (Korean Standard Time)|
|**App Generator**<br>@sap/generator-fiori-freestyle|
|**App Generator Version**<br>1.16.5|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>simple|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://bgissap3.bgissap.co.kr:8000/sap/opu/odata/sap/YGWC130_SRV|
|**Module Name**<br>expense.btrip|
|**Application Title**<br>신규 실비 등록|
|**Namespace**<br>code.d00|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.120.23|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|

## expense.btrip

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


